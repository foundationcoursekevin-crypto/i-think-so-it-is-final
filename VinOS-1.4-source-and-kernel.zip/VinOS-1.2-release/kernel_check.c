#define HOSTTEST 1
#include "kernel.c"
#include <stdio.h>

static int hit_exists(int id) {
    for (int j = 0; j < nhits; j++) if (hits[j].id == id) return 1;
    return 0;
}
static int desktop_hits_fit(void) {
    for (int i = 0; i < 6; i++) {
        int found = 0;
        for (int j = 0; j < nhits; j++) if (hits[j].id == 3000 + i) {
            Hit h = hits[j]; found = 1;
            if (h.x < 0 || h.y < 38 || h.x + h.w > (int)W || h.y + h.h > (int)H) return 0;
            break;
        }
        if (!found) return 0;
    }
    return 1;
}
static int desktop_apps_fit(void) {
    for (int i = 0; i <= app_count(); i++) {
        int found = 0;
        for (int j = 0; j < nhits; j++) if (hits[j].id == 1700 + i) {
            Hit h = hits[j]; found = 1;
            if (h.x < 0 || h.y < 0 || h.x + h.w > (int)W || h.y + h.h > (int)H) return 0;
            break;
        }
        if (!found) return 0;
    }
    return 1;
}
static int app_hits_fit(void) {
    for (int i = 0; i <= app_count(); i++) {
        int found = 0;
        for (int j = 0; j < nhits; j++) if (hits[j].id == 1700 + i) {
            Hit h = hits[j]; found = 1;
            if (h.x < 0 || h.y < 0 || h.x + h.w > (int)W || h.y + h.h > (int)H) return 0;
            break;
        }
        if (!found) return 0;
    }
    return 1;
}
int main(void) {
    W = 1366; H = 768; PITCH = W * 4; kernel_init(); compose(1000);
    if (theme_i != 6 || blur_r != 3 || win_alpha != 112) return 10;
    if (KEY_SPOTLIGHT != 0x111) return 11;
    if (launchpad_open || terminal_visible || app_on) return 12; /* first boot is a clean desktop */
    if (!home_node || !desktop_node || !documents_node || !downloads_node || !pictures_node) return 13;
    if (!desktop_hits_fit()) return 14;
    /* VinOS glass workspace is visible on the desktop: Spotlight, the complete app shelf,
       and the quick-control card are available without opening a full-screen launcher. */
    if (!hit_exists(2002) || !hit_exists(2001) || !hit_exists(2004)) return 35;
    if (!desktop_apps_fit()) return 36;
    if (!hit_exists(2100) || !hit_exists(2101) || !hit_exists(2102)) return 37;
    /* A visible desktop shortcut launches the actual application window. */
    ui_click(1704); task_sync(); if (app_on != 4 || win_find(4) < 0) return 38;
    win_close(4); compose(1050);
    ui_click(2002); if (!launcher_open) return 39; launcher_open = 0;
    launchpad_open = 1; compose(1060); if (!app_hits_fit()) return 40; launchpad_open = 0; compose(1070);

    /* Desktop right-click menu, folder creation, Gallery and wallpaper personalization. */
    desk_menu_open = 1; desk_menu_x = 200; desk_menu_y = 160; compose(1080);
    if (!hit_exists(2200) || !hit_exists(2201) || !hit_exists(2202)) return 43;
    ui_click(2200); if (!folder_prompt) return 44;
    { const char *nm = "TestFolder"; for (int z = 0; nm[z]; z++) handle_key(nm[z]); handle_key('\n'); }
    if (folder_prompt || fs_find(desktop_node, "TestFolder") < 0) return 45;
    compose(1090); if (!hit_exists(3100 + fs_find(desktop_node, "TestFolder"))) return 46;
    ui_click(2201); if (!gallery_open) return 47; handle_key(27); if (gallery_open) return 48;
    ui_click(2202); if (app_on != 9) return 49; app_on = 0;

    /* This PC opens a File Manager overview showing user folders and the C: RAM disk. */
    ui_click(3000); if (app_on != 7 || !fa_pc_view) return 15;
    task_sync(); compose(1100); if (!hit_exists(792)) return 16;
    for (int i = 0; i < 6; i++) if (!hit_exists(830 + i)) return 17;
    ui_click(792); if (fa_pc_view || fa_dir != 0) return 18;
    ui_click(3002); if (app_on != 7 || fa_dir != documents_node || fa_pc_view) return 19;

    /* Desktop and app controls remain available. */
    ui_click(2001); if (!launchpad_open) return 20;
    ui_click(2001); if (launchpad_open) return 21;
    ui_click(2003); if (!control_open) return 22;
    display_level = 90; ui_click(2101); if (display_level != 100) return 23;
    { int was = alerts_enabled; ui_click(2102); if (alerts_enabled == was) return 24; }
    handle_key(KEY_SPOTLIGHT); if (!launcher_open) return 25; launcher_open = 0;

    /* Launching Terminal from its Dock icon reveals its panel on demand. */
    ui_click(2); if (!terminal_visible) return 26;
    ui_click(2000); if (terminal_visible || !term_focus) return 27;

    app_at(6)->open(); task_sync(); if (win_find(7) < 0) return 28;
    ui_click(1400 + 7); if (win_find(7) < 0 || !win_[win_find(7)].max) return 29;
    ui_click(1300 + 7); if (win_find(7) < 0 || !win_[win_find(7)].min) return 30;
    ui_click(1000 + 7); if (win_find(7) >= 0) return 31;

    W = 1024; H = 600; PITCH = W * 4; nwin = 0; app_on = 0; terminal_visible = 0; build_scene(); compose(2000);
    if (!desktop_hits_fit() || !desktop_apps_fit()) return 32;
    launchpad_open = 1; compose(2100); if (!app_hits_fit()) return 41; launchpad_open = 0;
    W = 640; H = 480; PITCH = W * 4; nwin = 0; app_on = 0; terminal_visible = 0; build_scene(); compose(3000);
    if (!desktop_hits_fit() || !desktop_apps_fit()) return 33;
    launchpad_open = 1; compose(3100); if (!app_hits_fit()) return 42; launchpad_open = 0;
    if (dock_apps_shown >= app_count()) return 34;
    puts("VinOS 1.3 host UI checks: PASS (desktop context menu + new folders + Gallery + personalization + existing glass workspace)");
    return 0;
}
