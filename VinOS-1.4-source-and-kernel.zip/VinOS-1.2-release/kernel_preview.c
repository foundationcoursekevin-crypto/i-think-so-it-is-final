#define HOSTTEST 1
#include "kernel.c"
#include <stdio.h>
#include <stdlib.h>

static int write_ppm(const char *path, int width, int height) {
    FILE *f = fopen(path, "wb");
    if (!f) return 1;
    fprintf(f, "P6\n%d %d\n255\n", width, height);
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            u32 c = back[y * W + x];
            fputc((c >> 16) & 255, f); fputc((c >> 8) & 255, f); fputc(c & 255, f);
        }
    }
    fclose(f); return 0;
}
int main(int argc, char **argv) {
    int width = 1366, height = 768;
    const char *out = "VinOS-1.1-preview.ppm";
    if (argc > 1) width = atoi(argv[1]);
    if (argc > 2) height = atoi(argv[2]);
    if (argc > 3) out = argv[3];
    if (width < 480 || height < 400 || width > MAXW || height > MAXH) return 2;
    W = (u32)width; H = (u32)height; PITCH = W * 4;
    mx = pmx = width / 2; my = pmy = height / 2;
    kernel_init();
    isl_expand = 0; timer_on = 0; /* render the settled desktop preview */
    if (argc > 4) {
        if (argv[4][0] == 't') { desktop_open_this_pc(); task_sync(); }
        else if (argv[4][0] == 'c') control_open = 1;
        else if (argv[4][0] == 'l') launchpad_open = 1;
        else if (argv[4][0] == 's') { launcher_open = 1; scpy(launcher_query, "notes", sizeof launcher_query); launcher_len = 5; }
        else if (argv[4][0] == 'm') { desk_menu_open = 1; desk_menu_x = width / 2; desk_menu_y = height / 3; }
        else if (argv[4][0] == 'g') { gallery_open = 1; }
        else if (argv[4][0] == 'n') { folder_prompt = 1; scpy(new_folder_name, "My Folder", sizeof new_folder_name); new_folder_len = 9; }
    }
    compose(1000);
    return write_ppm(out, width, height);
}
