VinOS 1.2 - Glass Workspace
===========================

VinOS boots to its original desktop with a visible glass workspace dashboard.
The desktop keeps its own app icons and controls; it does not copy Apple logos,
Apple app artwork, or a pixel-for-pixel macOS layout.

Visible desktop experience
--------------------------
- Desktop shortcuts: This PC, Home, Documents, Downloads, Pictures, and the
  temporary VinOS RAM Disk (C:).
- A frosted-glass Spotlight-style search field is visible on the desktop.
  Clicking it opens the command palette; Win + Space opens the same palette.
- A translucent VinOS Workspace panel exposes Terminal and every built-in app
  in a clickable quick-launch grid.
- A visible Control Center card exposes network status, display brightness,
  speaker-alert status, battery-data status, and a link to the full controls.
- A floating glass Dock, original VinOS vector icons, custom wallpaper, and
  rounded translucent app windows remain part of the desktop.
- Apps menu / App Library opens the full app grid. The Control Center and
  Spotlight can also be opened from the top bar or their desktop controls.
- App windows retain close, minimize, maximize, focus, and drag behavior.

Built-in applications
---------------------
Calendar, Browser, Paint, Calculator, Clock, Notes, Files, Snake, Settings,
Monitor, and Terminal.

Storage accuracy / limitations
------------------------------
- C: is a RAM-backed VinOS filesystem. Files in it are temporary and are lost
  when the computer restarts or powers off.
- Physical laptop partitions are not mounted in this build. This kernel does
  not yet include ATA/AHCI/NVMe disk-controller drivers or a persistent
  filesystem driver. This PC explicitly says the physical storage driver is
  not loaded; it does not invent D: or E: drives.
- Home, Desktop, Documents, Downloads, Pictures, Music, Videos, and Projects
  folders are created in the RAM filesystem at startup.

Display sizing
--------------
- The kernel uses the pixel dimensions of the linear framebuffer supplied by
  GRUB; the included GRUB config requests gfxmode=auto and gfxpayload=keep.
- The UI has host-side layout tests at 1366x768, 1024x600, and 640x480.
- Those tests do not identify the physical diagonal (inches) of a Sony VAIO
  panel. The exact VAIO model or Windows display information is required.

Build and test
--------------
  make
  make host-test
  make host-preview
  make iso
  make run

`make` builds a freestanding 32-bit kernel ELF. `make iso` and `make run`
require grub-mkrescue, xorriso, and qemu-system-i386. They are not available
in the current build environment, so this delivery includes the source and
kernel ELF but not a bootable ISO. Booting on the actual VAIO remains untested.
Do not replace the existing Windows installation with this untested kernel.

Preview images are rendered from the kernel's C drawing code. They are not
screenshots captured from a live boot.
