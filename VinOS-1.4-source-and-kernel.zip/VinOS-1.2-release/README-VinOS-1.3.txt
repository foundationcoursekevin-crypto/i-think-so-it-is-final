VinOS 1.4 - VAIO-tuned Glass Workspace + Desktop Tools
===========================================

VinOS keeps its original visual identity and glass desktop while adding a
Windows-style desktop context menu and practical desktop tools.

New in 1.4
----------
- Right-click an empty desktop area to open the translucent Desktop menu.
- New Folder opens a name-entry dialog. Enter creates a real directory inside
  the VinOS Desktop folder on the C: RAM disk; Esc cancels.
- Created folders appear as desktop shortcuts and open in the Files manager.
- Gallery opens a Pictures view and displays visual tiles for files placed in
  the Pictures folder. The current filesystem does not decode/import image
  formats yet, so these tiles are file placeholders rather than photo previews.
- Personalize opens Settings, where the built-in glacier, night, aurora,
  sunset, nebula, prism and lumen wallpapers can be selected.
- The existing glass dashboard, dock, Spotlight, App Library, Control Center,
  This PC, and desktop shortcuts are retained.

Built-in applications
---------------------
Calendar, Browser, Paint, Calculator, Clock, Notes, Files, Snake, Settings,
Monitor, and Terminal.

Storage accuracy / limitations
------------------------------
C: is a RAM-backed VinOS filesystem. Folders/files are temporary and lost at
restart. Physical laptop partitions are not mounted; ATA/AHCI/NVMe and
persistent filesystem drivers are not included. Gallery currently lists
Pictures-folder entries with placeholder thumbnails; image decoding and
importing from physical drives are not implemented. Network, real battery telemetry, and full audio drivers are also not implemented.
The ACPI battery-method interpreter is not included, so the VAIO battery
percentage and charging state cannot yet be read.

Display clarity and performance
-------------------------------
The default glass blur radius is reduced and the duplicate full-screen blur
pass is removed. This reduces CPU work on older VAIO hardware while keeping
the original translucent look and sharper text/edges. The 1366x768 preview
size matches the VPCEH25EN panel resolution; it does not guarantee physical
panel sharpness or prove a live hardware boot.

Display sizing
--------------
Framebuffer pixel dimensions are supplied by GRUB. Host layout tests cover
1366x768, 1024x600, and 640x480; these do not establish the physical diagonal
of a Sony VAIO display.

Build and test
--------------
  make
  make host-test
  make host-preview
  make iso
  make run

`make` builds a freestanding 32-bit kernel ELF. A bootable ISO and live
hardware/QEMU test were not produced in this environment. Preview images are
rendered from the kernel's C drawing code, not captured from a live boot.
Do not replace an existing Windows installation with this untested kernel.
