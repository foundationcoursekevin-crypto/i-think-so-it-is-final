# VinOS 1.8
Upload this whole repo to GitHub. The "Build VinOS ISO" Action runs on every push
and produces `vinos.iso` and `vinos-100mb.iso` (exactly 100 MiB) under Actions -> latest run -> Artifacts -> vinos-iso.
