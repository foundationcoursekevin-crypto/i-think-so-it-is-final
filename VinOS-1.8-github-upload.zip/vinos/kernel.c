/* VinOS 1.8 - Glass Workspace desktop. Original VinOS identity with a compact responsive launcher,
 * translucent menu bar and familiar desktop conventions. Boots via GRUB Multiboot 1. */

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;

#define MAXW 1600
#define MAXH 900
#define KEY_UP 0x100
#define KEY_DOWN 0x101
#define KEY_LEFT 0x102
#define KEY_RIGHT 0x103
#define KEY_ALTTAB 0x110
#define KEY_SPOTLIGHT 0x111
static void mouse_packet(int btn, int dx, int dy);
static void mouse_drain(void); static void cursor_sync(void); static void power_off(void); static void power_restart(void);
static void run_in_terminal(const char *cmd);
static void hardware_probe(void);
static void build_scene(void);
static void desktop_open_this_pc(void);
static void desktop_open_folder(int which);
static void desktop_open_drive(void);
static void desktop_open_node(int node);
static int in_flip, pwr_arm; static unsigned pwr_until;
#define CUR_W 9
#define CUR_H 14
#define PWR_OFF_ID 900
#define PWR_RST_ID 901
/* ---- App registry: every app is one row in app_tab[] (bottom of apps.h) ---- */
typedef struct { const char *name, *cmd; void (*open)(void); void (*key)(int); void (*draw)(u32 *, u32);
                 void (*click)(int); void (*mouse)(int, int, int); void (*icon)(u32 *, int, int); int pw, ph; } App;
static int app_count(void); static const App *app_at(int i); static int app_fast;

#include "font.h"

/* ============================ hardware layer ============================ */
#ifdef HOSTTEST
#include <string.h>
static void outb(u16 p, u8 v)  { (void)p; (void)v; }
static u8   inb(u16 p)         { (void)p; return 0; }
static void outw(u16 p, u16 v) { (void)p; (void)v; }
static void outl(u16 p, u32 v) { (void)p; (void)v; }
static u32 inl(u16 p) { (void)p; return 0xFFFFFFFFu; }
static u32 host_ms;
static u32 now_ms(void) { return host_ms; }
static int poll_key(void) { return 0; }
static void mouse_init(void) {}
static void ps2_pump(void) {}
static void rtc_read(int *h, int *mi, int *sc, int *d, int *mo, int *y) {
    u32 t = host_ms / 1000 + 14 * 3600 + 7 * 60;
    *h = (t / 3600) % 24; *mi = (t / 60) % 60; *sc = t % 60; *d = 5; *mo = 11; *y = 2026;
}
static void speaker_on(int hz) { (void)hz; }
static void speaker_off(void) {}
#else
static inline void outb(u16 p, u8 v)  { __asm__ volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline u8   inb(u16 p)         { u8 v; __asm__ volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline void outw(u16 p, u16 v) { __asm__ volatile("outw %0,%1" :: "a"(v), "Nd"(p)); }
static inline void outl(u16 p, u32 v) { __asm__ volatile("outl %0,%1" :: "a"(v), "Nd"(p)); }
static inline u32  inl(u16 p)         { u32 v; __asm__ volatile("inl %1,%0" : "=a"(v) : "Nd"(p)); return v; }

void *memcpy(void *d, const void *s, unsigned n) {
    void *r = d; unsigned q = n >> 2, t = n & 3;
    __asm__ volatile("rep movsl" : "+D"(d), "+S"(s), "+c"(q) :: "memory");
    __asm__ volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(t) :: "memory"); return r;
}
void *memset(void *d, int c, unsigned n) {
    void *r = d; unsigned q = n >> 2, t = n & 3, v = (u8)c * 0x01010101u;
    __asm__ volatile("rep stosl" : "+D"(d), "+c"(q) : "a"(v) : "memory");
    __asm__ volatile("rep stosb" : "+D"(d), "+c"(t) : "a"(c) : "memory"); return r;
}
void *memmove(void *d, const void *s, unsigned n) {
    u8 *a = d; const u8 *b = s;
    if (a < b) { while (n--) *a++ = *b++; }
    else { a += n; b += n; while (n--) *--a = *--b; }
    return d;
}

/* millisecond clock polled from PIT channel 0 (no interrupts needed) */
static u32 now_ms(void) {
    static u32 ms = 0, rem = 0; static u16 last = 0;
    outb(0x43, 0x00);
    u16 c = inb(0x40); c |= (u16)inb(0x40) << 8;
    u16 d = (u16)(last - c); last = c;
    rem += d; ms += rem / 1193; rem %= 1193;
    return ms;
}

/* PS/2 keyboard, scancode set 1, polled */
static const char kn[] = "\0\x1b" "1234567890-=\b\tqwertyuiop[]\n\0asdfghjkl;'`\0\\zxcvbnm,./\0*\0 ";
static const char ks[] = "\0\x1b" "!@#$%^&*()_+\b\tQWERTYUIOP{}\n\0ASDFGHJKL:\"~\0|ZXCVBNM<>?\0*\0 ";
static u8 cmos(u8 r) { outb(0x70, r); return inb(0x71); }
static void rtc_read(int *h, int *mi, int *sc, int *d, int *mo, int *y) {   /* CMOS real-time clock */
    int guard = 0; while ((cmos(0x0A) & 0x80) && guard++ < 20000) {}
    u8 se = cmos(0), mn = cmos(2), hr = cmos(4), dy = cmos(7), mt = cmos(8), yr = cmos(9), b = cmos(0x0B);
    int pm = hr & 0x80; hr &= 0x7F;
    if (!(b & 4)) {
        se = (se & 15) + (se >> 4) * 10; mn = (mn & 15) + (mn >> 4) * 10; hr = (hr & 15) + (hr >> 4) * 10;
        dy = (dy & 15) + (dy >> 4) * 10; mt = (mt & 15) + (mt >> 4) * 10; yr = (yr & 15) + (yr >> 4) * 10;
    }
    if (!(b & 2)) { hr %= 12; if (pm) hr += 12; }
    *h = hr; *mi = mn; *sc = se; *d = dy; *mo = mt; *y = 2000 + yr;
}
/* PC speaker on PIT channel 2 */
static void speaker_on(int hz) {
    u32 div = 1193182 / (u32)hz;
    outb(0x43, 0xB6); outb(0x42, div & 255); outb(0x42, (div >> 8) & 255); outb(0x61, inb(0x61) | 3);
}
static void speaker_off(void) { outb(0x61, inb(0x61) & 0xFC); }

/* PS/2 mouse: 3-byte packets, polled from the same 8042 controller */
static void kbc_wait_w(void) { int t = 100000; while ((inb(0x64) & 2) && t--) {} }
static int kbc_wait_r(void) { int t = 100000; while (!(inb(0x64) & 1) && t--) {} return inb(0x64) & 1; }
static void mouse_cmd(u8 c) { kbc_wait_w(); outb(0x64, 0xD4); kbc_wait_w(); outb(0x60, c); if (kbc_wait_r()) inb(0x60); }
static void mouse_init(void) {
    for (int g = 0; g < 64 && (inb(0x64) & 1); g++) inb(0x60);       /* throw away anything left over from GRUB / BIOS */
    kbc_wait_w(); outb(0x64, 0xA8);                                   /* enable aux port */
    kbc_wait_w(); outb(0x64, 0x20); u8 cfg = kbc_wait_r() ? inb(0x60) : 0;
    cfg |= 2; cfg &= (u8)~0x20; kbc_wait_w(); outb(0x64, 0x60); kbc_wait_w(); outb(0x60, cfg);
    mouse_cmd(0xF6); mouse_cmd(0xF4);                                 /* defaults, start streaming */
}
static void mouse_byte(u8 b) {
    static int idx = 0; static u8 p[3];
    if (idx == 0 && !(b & 8)) return;                                 /* resync */
    p[idx++] = b;
    if (idx == 3) {
        idx = 0; if (p[0] & 0xC0) return;                              /* overflow = garbage packet */
        int dx = p[1] - ((p[0] << 4) & 0x100), dy = p[2] - ((p[0] << 3) & 0x100);
        mouse_packet(p[0] & 7, dx, -dy);
    }
}
static int key_scan(u8 sc) {
    static int shift = 0, caps = 0, ext = 0, alt = 0, super = 0;
    if (sc == 0xE0) { ext = 1; return 0; }
    int rel = sc & 0x80; sc &= 0x7F;
    if (sc == 0x38) { alt = !rel; ext = 0; return 0; }               /* left or right Alt */
    if (alt && sc == 0x0F && !rel) { ext = 0; return KEY_ALTTAB; }   /* Alt+Tab */
    if (ext) {
        ext = 0;
        if (sc == 0x5B || sc == 0x5C) { super = !rel; return 0; } /* left/right Windows key */
        if (!rel) { if (sc == 0x48) return KEY_UP; if (sc == 0x50) return KEY_DOWN; if (sc == 0x4B) return KEY_LEFT; if (sc == 0x4D) return KEY_RIGHT; }
        return 0;
    }
    if (super && sc == 0x39 && !rel) return KEY_SPOTLIGHT; /* Win + Space */
    if (sc == 0x2A || sc == 0x36) { shift = !rel; return 0; }
    if (rel) return 0;
    if (sc == 0x3A) { caps = !caps; return 0; }
    if (sc >= 58) return 0;
    char c = shift ? ks[sc] : kn[sc];
    if (caps && !shift && c >= 'a' && c <= 'z') c -= 32;
    else if (caps && shift && c >= 'A' && c <= 'Z') c += 32;
    return (u8)c;
}
static u8 kq[64]; static int kqh, kqt;
static void ps2_pump(void) {                 /* called often, also from inside the drawing code: mouse packets are decoded the moment they arrive */
    for (int g = 0; g < 128; g++) {
        u8 st = inb(0x64); if (!(st & 1)) break; u8 sc = inb(0x60);
        if (st & 0x20) mouse_byte(sc);
        else { int n = (kqt + 1) & 63; if (n != kqh) { kq[kqt] = sc; kqt = n; } }
    }
    cursor_sync();                           /* pointer follows the mouse even while a frame is still being drawn */
}
static int poll_key(void) {
    ps2_pump(); mouse_drain();
    while (kqh != kqt) { u8 sc = kq[kqh]; kqh = (kqh + 1) & 63; int k = key_scan(sc); if (k) return k; }
    return 0;
}
#endif

/* ============================ framebuffer ============================ */
static u32 W = 1024, H = 768, PITCH = 4096;
static u32 *fb;
static u32 mem_kb = 131072;
#define WIN_TINT 0x1C1C1E   /* one dark glass material shared by the Terminal and every app window */
static int win_alpha = 214, blur_r = 8, prompt_mode, app_on, dock_ix0; /* rich frosted glass; blur runs once per scene and is cached, so it does not cost per-frame speed */
static int launcher_open; static char launcher_query[48]; static int launcher_len;
static int desk_menu_open, folder_prompt, gallery_open, desk_menu_x, desk_menu_y;
static char new_folder_name[24]; static int new_folder_len;
static int terminal_visible; /* desktop is the default; Terminal is opened on demand */
static int fa_pc_view; /* Files window is currently showing the This PC overview */
static int launchpad_open, control_open;
static int display_level = 100, alerts_enabled = 1;
static int acpi_present, audio_device_present;
static int mx = 512, my = 384, pmx = 512, pmy = 384, mbtn, mouse_seen;   /* mx,my = position the UI logic sees; pmx,pmy = raw pointer, updated instantly */
typedef struct { int x, y, w, h, id; } Hit;
static Hit hits[256]; static int nhits;
static void hit_add(int x, int y, int w, int h, int id) { if (nhits < 256) { hits[nhits].x = x; hits[nhits].y = y; hits[nhits].w = w; hits[nhits].h = h; hits[nhits].id = id; nhits++; } }
static int hot(int x, int y, int w, int h) { return mouse_seen && mx >= x && mx < x + w && my >= y && my < y + h; }
static char wtitle[40] = "Terminal  -  VinOS", prompt_txt[24];
static u32 bgbuf[MAXW * MAXH];     /* pre-rendered static scene: Prism wallpaper + floating glass panels */
static u32 bgblur[MAXW * MAXH];     /* blurred wallpaper: the 'frosted' backdrop for floating windows */
static u32 back[MAXW * MAXH];      /* per-frame composition target (also scratch while building the scene) */
static u32 la[MAXW], lb[MAXW];

#define D255(v) ((((v) + 128) + (((v) + 128) >> 8)) >> 8)
static inline u32 mix(u32 d, u32 s, u32 a) {
    if (a == 0) return d;
    if (a >= 255) return s;
    u32 ia = 255 - a;
    u32 r = ((d >> 16) & 255) * ia + ((s >> 16) & 255) * a; r = D255(r);
    u32 g = ((d >> 8) & 255) * ia + ((s >> 8) & 255) * a;  g = D255(g);
    u32 b = (d & 255) * ia + (s & 255) * a;                 b = D255(b);
    return (r << 16) | (g << 8) | b;
}

/* VinOS frosted glass: strengthen colour and highlights for the original desktop material. */
static void lift(u32 *b, int n, int sat, int white) {
    for (int k = 0; k < n; k++) {
        u32 c = b[k]; int r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255, gr = (r * 30 + g * 59 + bl * 11) / 100;
        r = gr + (r - gr) * sat / 100; g = gr + (g - gr) * sat / 100; bl = gr + (bl - gr) * sat / 100;
        r = r < 0 ? 0 : (r > 255 ? 255 : r); g = g < 0 ? 0 : (g > 255 ? 255 : g); bl = bl < 0 ? 0 : (bl > 255 ? 255 : bl);
        b[k] = mix(((u32)r << 16) | ((u32)g << 8) | (u32)bl, 0xFFFFFF, (u32)white);
    }
}
/* rim light strength at (i,j): bright specular edge at the top-left, a faint glint at the bottom-right, soft in between */
static u32 rim_a(int i, int j, int w, int h, u32 base) {
    int u = (i * 255 / (w > 1 ? w : 1) + j * 255 / (h > 1 ? h : 1)) / 2;
    u32 spec = u < 128 ? (u32)(255 - u * 2) : (u32)((u - 128) * 2 * 45 / 100);
    return base * (70 + spec * 185 / 255) / 255;
}

/* anti-aliased rounded-rect coverage 0..255 for pixel (px,py) in rect (x,y,w,h,r) */
static u32 rr_cov(int px, int py, int x, int y, int w, int h, int r) {
    if (px < x || py < y || px >= x + w || py >= y + h) return 0;
    if (r <= 0) return 255;
    int cx = px < x + r ? x + r : (px >= x + w - r ? x + w - r - 1 : px);
    int cy = py < y + r ? y + r : (py >= y + h - r ? y + h - r - 1 : py);
    int dx = px - cx, dy = py - cy, d2 = dx * dx + dy * dy;
    if (d2 <= (r - 1) * (r - 1)) return 255;
    int R = 2 * r + 1;
    int v = (R * R - 4 * d2) * 255 / (4 * R);
    return v < 0 ? 0 : (v > 255 ? 255 : (u32)v);
}

static int hole_x, hole_y, hole_w, hole_h;      /* draw_rr skips this rectangle when hole_w > 0 */
static void draw_rr(u32 *buf, int x, int y, int w, int h, int r, u32 col, u32 alpha) {
    if (w <= 0 || h <= 0 || alpha == 0) return;
    if (2 * r > w) r = w / 2; if (2 * r > h) r = h / 2; if (r < 0) r = 0;
    int xa = x < 0 ? 0 : x, xb = x + w > (int)W ? (int)W : x + w;
    for (int j = 0; j < h; j++) {
        int yy = y + j; if (yy < 0 || yy >= (int)H) continue;
        int band = j < r || j >= h - r; u32 *row = &buf[yy * W]; int inh = hole_w > 0 && yy >= hole_y && yy < hole_y + hole_h;
        for (int xx = xa; xx < xb; xx++) {
            if (inh && xx >= hole_x && xx < hole_x + hole_w) { xx = hole_x + hole_w - 1; continue; }
            int i = xx - x; u32 a = alpha;
            if (band && (i < r || i >= w - r)) { u32 c = rr_cov(xx, yy, x, y, w, h, r); if (!c) continue; a = c * alpha / 255; }
            row[xx] = a >= 255 ? col : mix(row[xx], col, a);
        }
    }
}

static void draw_line(u32 *buf, int x0, int y0, int x1, int y1, u32 col, u32 a) {
    int dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = y1 > y0 ? y0 - y1 : y1 - y0;
    int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx + dy;
    for (;;) {
        for (int k = 0; k < 2; k++) {
            int xx = x0 + k, yy = y0;
            if (xx >= 0 && yy >= 0 && xx < (int)W && yy < (int)H) { u32 *p = &buf[yy * W + xx]; *p = mix(*p, col, a); }
        }
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * e;
        if (e2 >= dy) { e += dy; x0 += sx; }
        if (e2 <= dx) { e += dx; y0 += sy; }
    }
}

static void glyph(u32 *buf, int x, int y, int c, u32 col) {
    if (c < 32 || c > 126) c = '?';
    const u8 *g = font[c - 32];
    for (int j = 0; j < 16; j++) {
        int yy = y + j; if (yy < 0 || yy >= (int)H) continue;
        for (int i = 0; i < 8; i++) {
            u8 a = g[j * 8 + i]; if (!a) continue;
            int xx = x + i; if (xx < 0 || xx >= (int)W) continue;
            u32 *p = &buf[yy * W + xx]; *p = mix(*p, col, a);
        }
    }
}
static void text(u32 *buf, int x, int y, const char *s, u32 col) { for (; *s; s++, x += 8) glyph(buf, x, y, *s, col); }

/* ---- frosted glass: blur what's behind, tint, top sheen, 1px rim light ---- */
static void box_line(const u32 *in, u32 *out, int n, int r) {
    int win = 2 * r + 1; u32 sr = 0, sg = 0, sb = 0;
    for (int i = -r; i <= r; i++) { int j = i < 0 ? 0 : (i >= n ? n - 1 : i); u32 c = in[j]; sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255; }
    for (int i = 0; i < n; i++) {
        out[i] = ((sr / win) << 16) | ((sg / win) << 8) | (sb / win);
        int a = i - r, b = i + r + 1; a = a < 0 ? 0 : a; b = b >= n ? n - 1 : b;
        u32 ca = in[a], cb = in[b];
        sr += ((cb >> 16) & 255) - ((ca >> 16) & 255); sg += ((cb >> 8) & 255) - ((ca >> 8) & 255); sb += (cb & 255) - (ca & 255);
    }
}
static void blur_rect(u32 *reg, int w, int h, int r) {
    for (int j = 0; j < h; j++) { box_line(reg + j * w, lb, w, r); memcpy(reg + j * w, lb, w * 4); }
    for (int i = 0; i < w; i++) {
        for (int j = 0; j < h; j++) la[j] = reg[j * w + i];
        box_line(la, lb, h, r);
        for (int j = 0; j < h; j++) reg[j * w + i] = lb[j];
    }
}
static void glass(int x, int y, int w, int h, int r, u32 tint, int ta, int sheen, int ba) {
    u32 *reg = back;
    for (int j = 0; j < h; j++) memcpy(reg + j * w, bgbuf + (y + j) * W + x, w * 4);
    if (blur_r > 0) blur_rect(reg, w, h, blur_r);
    lift(reg, w * h, 185, 30);
    for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
        u32 co = rr_cov(i, j, 0, 0, w, h, r); if (!co) continue;
        u32 ci = rr_cov(i, j, 1, 1, w - 2, h - 2, r > 0 ? r - 1 : 0);
        u32 *p = &bgbuf[(y + j) * W + x + i];
        u32 d = mix(*p, reg[j * w + i], co);
        d = mix(d, tint, (u32)ta * ci / 255);
        int s = h - j; u32 sh = (u32)(sheen * (s * s / h) / h); if (sh > 255) sh = 255;
        d = mix(d, 0xFFFFFF, sh * ci / 255);
        u32 bd = co > ci ? co - ci : 0;
        d = mix(d, 0xFFFFFF, rim_a(i, j, w, h, (u32)ba) * bd / 255);
        if (i < r || i >= w - r || j < r || j >= h - r) {                       /* inner glow just inside the rim */
            u32 cn = rr_cov(i, j, 3, 3, w - 6, h - 6, r > 3 ? r - 3 : 0), gl = ci > cn ? ci - cn : 0;
            d = mix(d, 0xFFFFFF, rim_a(i, j, w, h, 46) * gl / 255);
        }
        *p = d;
    }
}

/* ---- VinOS original landscape wallpapers ---- */
static int tri(int x, int p) { x %= p; if (x < 0) x += p; return x < p / 2 ? x : p - x; }
static int ridge(int x, int p, int off) { return tri(x + off, p) * 255 / (p / 2); }
static int topy[MAXW];

typedef struct { const char *name; u32 sky[3]; u32 col[3][3]; u32 fog, tint, clk; } Theme;
#define THEME_COUNT 7
static const Theme themes[THEME_COUNT] = {
    {"glacier", {0x061A33, 0x2E78A8, 0xCDEAF6}, {{0x6F9BBD, 0x8DB8D6, 0x56809F}, {0xA6CDE5, 0xC9E6F5, 0x84B0CE}, {0xD7F0FA, 0xF4FBFF, 0xA6D3E8}}, 0xE2F4FB, 0x07172B, 0x0B2A44},
    {"night",   {0x02040D, 0x0B1D3F, 0x2A4A7A}, {{0x1B2F55, 0x2A4573, 0x13223F}, {0x2B4676, 0x3D5E92, 0x1E3560}, {0x3E5F94, 0x5B7FB4, 0x2C4A7C}}, 0x3A5A8E, 0x050B18, 0xDCEEFF},
    {"aurora",  {0x03121F, 0x0E6B5C, 0x7BE8C2}, {{0x2F7F86, 0x47A3A0, 0x216066}, {0x5FB7B0, 0x84D6C4, 0x3E8F8C}, {0xA9E6DC, 0xD4FAF1, 0x7FC9C0}}, 0xC8F3EA, 0x06201E, 0x07342E},
    {"sunset",  {0x2B1245, 0xC4476F, 0xFFC27A}, {{0x8C4F7F, 0xB06A8B, 0x6A3A6B}, {0xC9778E, 0xE897A0, 0x9A5778}, {0xF3B7A5, 0xFFD8C0, 0xC98595}}, 0xFFE0C2, 0x2A1030, 0x4A1F3A},
    {"nebula", {0x090D29, 0x343D85, 0xB95EAE}, {{0x273C70, 0x435BA0, 0x182B59}, {0x654E9A, 0x846DB8, 0x493A7C}, {0xB46BAA, 0xD48FC3, 0x89518C}}, 0xD9B8E8, 0x101638, 0xD9E6FF},
    {"prism",  {0x070B20, 0x25366E, 0x7A4E9C}, {{0x15264E, 0x294D78, 0x101C3D}, {0x263A70, 0x3B5F91, 0x1A2C58}, {0x534B88, 0x7466A8, 0x38406D}}, 0x111A38, 0x28396A, 0xE6EEFF},
    {"lumen",  {0x10152D, 0x48628E, 0xD4A7C9}, {{0x354C79, 0x587AA8, 0x22395F}, {0x526B98, 0x7D96BE, 0x38527E}, {0x967DAA, 0xBCA2C8, 0x6E628F}}, 0xC6C2DA, 0x394A76, 0xF0E8FF},
};
static int theme_i = 6;

static void paint_bg(void) {
    const Theme *T = &themes[theme_i];
    int hz = (int)H * 62 / 100;
    for (int y = 0; y < (int)H; y++) {
        u32 c;
        if (y >= hz) c = T->fog;
        else { int t = y * 255 / hz; c = t < 128 ? mix(T->sky[0], T->sky[1], t * 2) : mix(T->sky[1], T->sky[2], (t - 128) * 2); }
        for (u32 x = 0; x < W; x++) {
            u32 px = c;
            if (theme_i == 5 && (int)y < (int)(H * 48 / 100)) {
                int wave = (int)H * 13 / 100 + ridge((int)x, (int)(W / 2 ? W / 2 : 1), 43) * ((int)H * 13 / 100) / 255;
                int d = (int)y - wave; if (d < 0) d = -d;
                if (d < (int)H * 5 / 100) {
                    int a = ((int)H * 5 / 100 - d) * 2; if (a > 72) a = 72;
                    u32 glow = theme_i == 6 ? mix(0xFFB6D9, 0x78D8E8, (int)x * 255 / (int)W)
                                               : mix(0x35D5D4, 0xA56BFF, (int)x * 255 / (int)W);
                    px = mix(px, glow, (u32)a);
                }
                int wave2 = (int)H * 31 / 100 + ridge((int)x + 117, (int)(W / 3 ? W / 3 : 1), 91) * ((int)H * 7 / 100) / 255;
                int d2 = (int)y - wave2; if (d2 < 0) d2 = -d2;
                if (d2 < (int)H * 3 / 100) {
                    int a = ((int)H * 3 / 100 - d2) * 2; if (a > 42) a = 42;
                    px = mix(px, theme_i == 6 ? 0x9A83EF : 0x4A80E8, (u32)a);
                }
            }
            bgbuf[y * W + x] = px;
        }
    }
    for (int i = 0; i < 120; i++) {              /* drifting snow specks */
        int x = (i * 7919 + 131) % (int)W, y = (i * 104729 + 977) % hz, a = 90 + (i * 37) % 130;
        for (int k = 0; k < (i % 5 == 0 ? 2 : 1); k++)
            for (int l = 0; l < (i % 5 == 0 ? 2 : 1); l++) { u32 *p = &bgbuf[(y + l) * W + x + k]; *p = mix(*p, 0xFFFFFF, a); }
    }
    static const int base[3] = {60, 72, 84}, amp[3] = {23, 19, 12};
    static const int pa[3][4] = {{620, 260, 97, 40}, {470, 190, 71, 200}, {360, 150, 59, 333}};
    for (int L = 0; L < 3; L++) {
        for (u32 x = 0; x < W; x++) {
            int h = (ridge(x, pa[L][0], pa[L][3]) * 5 + ridge(x, pa[L][1], pa[L][3] / 2) * 2 + ridge(x, pa[L][2], 5)) / 8;
            topy[x] = (int)H * base[L] / 100 - h * ((int)H * amp[L] / 100) / 255;
        }
        for (u32 x = 0; x < W; x++) {
            int sl = topy[x > 18 ? x - 18 : 0] - topy[x + 18 < W ? x + 18 : W - 1];   /* broad slope: lit west faces, shaded east faces */
            u32 c0 = sl > 5 ? T->col[L][1] : (sl < -5 ? T->col[L][2] : T->col[L][0]);
            for (int y = topy[x]; y < (int)H; y++) {
                int dy = y - topy[x];
                u32 c = c0;
                u32 fog = (u32)(dy * 255 / ((int)H * 30 / 100)); if (fog > 190) fog = 190;
                c = mix(c, T->fog, fog);
                if (dy < 14) c = mix(c, 0xFFFFFF, (u32)(14 - dy) * 16);
                bgbuf[y * W + x] = c;
            }
        }
    }
}

/* ============================ layout / scene ============================ */
static int wx, wy, ww, wh, tx, ty, cols, rows, dkx, dky, dkw, dkh, dock_apps_shown;
#define COLS_MAX 160
#define ROWS_MAX 60
static u32 pal[] = {0xF2F2F7, 0x64D2FF, 0xAEAEB2, 0xFF6961, 0x30D158, 0xFFD60A};   /* macOS dark system colours */
enum { A_TXT, A_ACC, A_DIM, A_ERR, A_OK, A_WARN };

/* ============================ window manager: every app gets its own floating window ============================ */
/* Apps set app_on to open/close themselves; task_sync() (once per frame) turns that into windows.
 * win_[] is in z-order (last = top = keyboard focus). term_focus = the terminal has the keyboard. */
static int slen(const char *s); static int dirty;
static void copy_rr(u32 *dst, const u32 *src, int x, int y, int w, int h, int r);
static void glass_finish(u32 *b, int x, int y, int w, int h, int r, int sheen, int rim);
#define WCACHE_PX 540000
static u32 wcache[8][WCACHE_PX]; static u32 gscratch[MAXW * MAXH];
static struct { int ok, x, y, w, h, alpha, blur; u32 tint; } wck[8];
typedef struct { int app, x, y, w, h, max, min, rx, ry, rw, rh; } Win;
static Win win_[8]; static int nwin, term_focus, drag_app, drag_ox, drag_oy, dock_peek;
static int win_find(int app) { for (int i = 0; i < nwin; i++) if (win_[i].app == app) return i; return -1; }
static void win_raise(int i) { Win t = win_[i]; for (int j = i; j < nwin - 1; j++) win_[j] = win_[j + 1]; win_[nwin - 1] = t; }
static void win_clamp(Win *w) {
    if (w->x > (int)W - w->w) w->x = (int)W - w->w; if (w->y > dky - 8 - w->h) w->y = dky - 8 - w->h;
    if (w->x < 0) w->x = 0; if (w->y < 0) w->y = 0;
}
static void win_create(int app) {
    const App *ap = app_at(app - 1); int w = ap->pw ? ap->pw : 640, h = ap->ph ? ap->ph : 440;
    if (w > (int)W - 20) w = (int)W - 20; if (h > dky - 16) h = dky - 16;
    if (nwin >= 6) { for (int j = 0; j < nwin - 1; j++) win_[j] = win_[j + 1]; nwin--; }
    int n = nwin % 5; Win nw = {0}; nw.app = app; nw.w = w; nw.h = h;
    nw.x = ((int)W - w) / 2 + (n - 2) * 34; nw.y = 68 + n * 24; win_clamp(&nw); win_[nwin++] = nw;
}
static void win_focus_top(void) {          /* after a close/minimize: topmost visible window gets the keyboard, else the terminal */
    if (nwin > 0 && !win_[nwin - 1].min) { term_focus = 0; app_on = win_[nwin - 1].app; }
    else { term_focus = nwin > 0; app_on = 0; }
    dirty = 1;
}
static void win_min_i(int i) { Win t = win_[i]; t.min = 1; for (int j = i; j > 0; j--) win_[j] = win_[j - 1]; win_[0] = t; }   /* minimized windows sit at the bottom */
static void win_close(int app) {
    int i = win_find(app); if (i < 0) return;
    for (int j = i; j < nwin - 1; j++) win_[j] = win_[j + 1];
    nwin--; win_focus_top();
}
static void win_minimize(int app) { int i = win_find(app); if (i < 0) return; win_min_i(i); win_focus_top(); }
static void win_toggle_max(int app) {
    int i = win_find(app); if (i < 0) return; Win *w = &win_[i];
    if (w->max) { w->x = w->rx; w->y = w->ry; w->w = w->rw; w->h = w->rh; w->max = 0; }
    else { w->rx = w->x; w->ry = w->y; w->rw = w->w; w->rh = w->h; w->x = 0; w->y = 38; w->w = (int)W; w->h = (int)H - 38; w->max = 1; }
    dirty = 1;
}
static int dock_hidden(void) { for (int i = nwin - 1; i >= 0; i--) { if (win_[i].min) continue; return win_[i].max; } return 0; }
static void focus_terminal(void) {          /* show the terminal: maximized windows get minimized so it is reachable */
    int rebuild = !terminal_visible; terminal_visible = 1; if (rebuild) build_scene(); term_focus = 1; app_on = 0;
    for (;;) { int f = -1; for (int i = 0; i < nwin; i++) if (win_[i].max && !win_[i].min) { f = i; break; } if (f < 0) break; win_min_i(f); }
    dirty = 1;
}
static void win_cycle(void) {               /* Alt+Tab */
    int vis = 0, lo = -1; for (int i = 0; i < nwin; i++) if (!win_[i].min) { vis++; if (lo < 0) lo = i; }
    if (vis >= 2) { win_raise(lo); term_focus = 0; app_on = win_[nwin - 1].app; }
    else if (vis == 1) { if (term_focus) { term_focus = 0; app_on = win_[nwin - 1].app; } else focus_terminal(); }
    else if (nwin > 0) { win_[nwin - 1].min = 0; term_focus = 0; app_on = win_[nwin - 1].app; }
    dirty = 1;
}
static void task_sync(void) {
    if (app_on == 0) {
        if (nwin > 0 && !term_focus) { nwin--; win_focus_top(); }   /* focused app closed itself */
        return;
    }
    term_focus = 0;
    int i = win_find(app_on);
    if (i < 0) win_create(app_on); else { if (win_[i].min) win_[i].min = 0; if (i != nwin - 1) win_raise(i); }
}
static void win_focus_at(int x, int y) {
    for (int i = nwin - 1; i >= 0; i--) {
        Win w = win_[i]; if (w.min) continue;
        if (x >= w.x && x < w.x + w.w && y >= w.y && y < w.y + w.h) { term_focus = 0; if (i != nwin - 1) win_raise(i); app_on = w.app; return; }
    }
    if (nwin > 0 && x >= wx && x < wx + ww && y >= wy && y < wy + wh) { term_focus = 1; app_on = 0; }
}
/* glass window: backdrop + tint + sheen + rim is rendered once into a cache and only re-rendered when the window moves or the style changes */
static void win_glass(u32 *b, const Win *w, int rd) {
    int s = w->app - 1, n = w->w * w->h;
    if (s < 0 || s > 7 || n > WCACHE_PX) { copy_rr(b, bgblur, w->x, w->y, w->w, w->h, rd); draw_rr(b, w->x, w->y, w->w, w->h, rd, WIN_TINT, (u32)win_alpha); glass_finish(b, w->x, w->y, w->w, w->h, rd, 52, 200); return; }
    u32 *c = wcache[s]; u32 tint = WIN_TINT;
    if (!(wck[s].ok && wck[s].x == w->x && wck[s].y == w->y && wck[s].w == w->w && wck[s].h == w->h && wck[s].alpha == win_alpha && wck[s].blur == blur_r && wck[s].tint == tint)) {
        for (int j = 0; j < w->h; j++) memcpy(&gscratch[(w->y + j) * W + w->x], &bgblur[(w->y + j) * W + w->x], w->w * 4);
        draw_rr(gscratch, w->x, w->y, w->w, w->h, rd, tint, (u32)win_alpha); glass_finish(gscratch, w->x, w->y, w->w, w->h, rd, 52, 200);
        for (int j = 0; j < w->h; j++) memcpy(&c[j * w->w], &gscratch[(w->y + j) * W + w->x], w->w * 4);
        wck[s].ok = 1; wck[s].x = w->x; wck[s].y = w->y; wck[s].w = w->w; wck[s].h = w->h; wck[s].alpha = win_alpha; wck[s].blur = blur_r; wck[s].tint = tint;
    }
    int r = rd; if (2 * r > w->w) r = w->w / 2; if (2 * r > w->h) r = w->h / 2;
    for (int j = 0; j < w->h; j++) {
        int yy = w->y + j; if (yy < 0 || yy >= (int)H) continue;
        u32 *src = &c[j * w->w], *dst = &b[yy * W + w->x];
        if (!(j < r || j >= w->h - r)) { memcpy(dst, src, w->w * 4); continue; }
        for (int i = 0; i < w->w; i++) {
            if (i < r || i >= w->w - r) { u32 cv = rr_cov(w->x + i, yy, w->x, w->y, w->w, w->h, r); if (cv) dst[i] = mix(dst[i], src[i], cv); } else dst[i] = src[i];
        }
    }
}
/* Mac-style window controls, shared by the Terminal and all apps: red close, yellow minimise, green zoom. live3 = 0 greys the zoom light. */
static void traffic_lights(u32 *b, int x, int y, int foc, int live3) {
    for (int d = 0; d < 3; d++) {
        int dx = x + 14 + d * 22, dy = y + 9;
        u32 cc = d == 0 ? 0xFF6E79 : (d == 1 ? 0xF6C66F : 0x62D7B0); u32 a = hot(dx, dy, 14, 14) ? 255 : (foc ? 226 : 150);
        if (d == 2 && !live3) { cc = 0x7B8498; a = 120; }
        draw_rr(b, dx, dy, 14, 14, 7, cc, a);
        if (d == 0 && hot(dx, dy, 14, 14)) { draw_line(b, dx + 4, dy + 4, dx + 10, dy + 10, 0x4B2030, 230); draw_line(b, dx + 10, dy + 4, dx + 4, dy + 10, 0x4B2030, 230); }
        else if (d == 1 && hot(dx, dy, 14, 14)) draw_line(b, dx + 4, dy + 7, dx + 10, dy + 7, 0x59431A, 230);
        else if (d == 2 && live3 && hot(dx, dy, 14, 14)) { draw_line(b, dx + 4, dy + 7, dx + 10, dy + 7, 0x174B3A, 230); draw_line(b, dx + 7, dy + 4, dx + 7, dy + 10, 0x174B3A, 230); }
    }
}
static void wins_draw(u32 *b, u32 ms) {
    int ox = wx, oy = wy, ow = ww, oh = wh;
    for (int i = 0; i < nwin; i++) {
        Win w = win_[i]; if (w.min) continue; const App *ap = app_at(w.app - 1); int foc = (i == nwin - 1 && !term_focus), rd = w.max ? 0 : 24;
        if (!w.max) { hole_x = w.x; hole_y = w.y; hole_w = w.w; hole_h = w.h; for (int s = 0; s < 3; s++) draw_rr(b, w.x - s + 2, w.y - s + 10, w.w + 2 * s, w.h + 2 * s, 26 + s, 0x04101E, 14); hole_w = 0; }
        if (blur_r > 0 && !w.max) win_glass(b, &w, rd);
        else draw_rr(b, w.x, w.y, w.w, w.h, rd, WIN_TINT, 255);
        draw_rr(b, w.x, w.y, w.w, 34, rd, 0xFFFFFF, foc ? 30 : 14);
        const char *title = (w.app == 7 && fa_pc_view) ? "This PC" : ap->name;
        text(b, w.x + (w.w - 8 * slen(title)) / 2, w.y + 9, title, foc ? pal[A_TXT] : pal[A_DIM]);
        traffic_lights(b, w.x, w.y, foc, 1);
        draw_line(b, w.x + 1, w.y + 34, w.x + w.w - 2, w.y + 34, 0xFFFFFF, foc ? 34 : 18);   /* title-bar divider, same on every window */
        hit_add(w.x, w.y, w.w, w.h, 1100 + w.app); hit_add(w.x, w.y, w.w, 34, 1200 + w.app);
        hit_add(w.x + 10, w.y + 5, 20, 22, 1000 + w.app);
        hit_add(w.x + 32, w.y + 5, 20, 22, 1300 + w.app);
        hit_add(w.x + 54, w.y + 5, 20, 22, 1400 + w.app);
        wx = w.x; wy = w.y; ww = w.w; wh = w.h;
        ps2_pump(); if (ap->draw) ap->draw(b, ms);
    }
    wx = ox; wy = oy; ww = ow; wh = oh;
}
/* the dock is baked into bgbuf; when a maximized window hides it, paint it back on top (rounded) while the mouse is at the bottom edge */
static void dock_overlay(u32 *b) {
    for (int i = 0; i < 8; i++) draw_rr(b, dkx - i, dky - i + 8, dkw + 2 * i, dkh + 2 * i, 28 + i, 0x04101E, 6);
    int r = 28;
    for (int y = dky; y < dky + dkh && y < (int)H; y++) for (int x = dkx; x < dkx + dkw && x < (int)W; x++) {
        int ddx = x < dkx + r ? dkx + r - x : (x >= dkx + dkw - r ? x - (dkx + dkw - 1 - r) : 0), ddy = y < dky + r ? dky + r - y : (y >= dky + dkh - r ? y - (dky + dkh - 1 - r) : 0);
        if (ddx * ddx + ddy * ddy <= r * r) b[y * W + x] = bgbuf[y * W + x];
    }
}

/* ---- glass for floating windows: pre-blurred wallpaper backdrop + tint + sheen + rim light ---- */
static void copy_rr(u32 *dst, const u32 *src, int x, int y, int w, int h, int r) {
    if (2 * r > w) r = w / 2; if (2 * r > h) r = h / 2; if (r < 0) r = 0;
    int xa = x < 0 ? 0 : x, xb = x + w > (int)W ? (int)W : x + w; if (xb <= xa) return;
    for (int j = 0; j < h; j++) {
        int yy = y + j; if (yy < 0 || yy >= (int)H) continue;
        if (!(j < r || j >= h - r)) { memcpy(&dst[yy * W + xa], &src[yy * W + xa], (xb - xa) * 4); continue; }
        for (int xx = xa; xx < xb; xx++) {
            int i = xx - x; u32 *d = &dst[yy * W + xx];
            if (i < r || i >= w - r) { u32 c = rr_cov(xx, yy, x, y, w, h, r); if (c) *d = mix(*d, src[yy * W + xx], c); } else *d = src[yy * W + xx];
        }
    }
}
static void glass_finish(u32 *b, int x, int y, int w, int h, int r, int sheen, int rim) {
    if (2 * r > w) r = w / 2; if (2 * r > h) r = h / 2; if (r < 0) r = 0;
    int hh = h < 170 ? h : 170, xa = x + r < 0 ? 0 : x + r, xb = x + w - r > (int)W ? (int)W : x + w - r;
    for (int j = 0; j < hh; j++) {                                    /* soft light from the top edge */
        int yy = y + j; if (yy < 0 || yy >= (int)H) continue; int s = hh - j; u32 sh = (u32)(sheen * (s * s / hh) / hh); if (sh > 255) sh = 255; if (!sh) continue;
        for (int xx = xa; xx < xb; xx++) b[yy * W + xx] = mix(b[yy * W + xx], 0xFFFFFF, sh);
    }
    for (int j = 0; j < h; j++) {                                     /* 1px rim light, only where it can exist */
        int yy = y + j; if (yy < 0 || yy >= (int)H) continue;
        for (int i = 0; i < w; i++) {
            int edge = i < 4 || i >= w - 4 || j < 4 || j >= h - 4, corner = (i < r || i >= w - r) && (j < r || j >= h - r);
            if (!edge && !corner) { if (i == 4) i = w - 5; continue; }
            int xx = x + i; if (xx < 0 || xx >= (int)W) continue;
            u32 co = rr_cov(i, j, 0, 0, w, h, r), ci = rr_cov(i, j, 1, 1, w - 2, h - 2, r > 0 ? r - 1 : 0), bd = co > ci ? co - ci : 0;
            u32 cn = rr_cov(i, j, 3, 3, w - 6, h - 6, r > 3 ? r - 3 : 0), gl = ci > cn ? ci - cn : 0;
            u32 *pp = &b[yy * W + xx];
            if (bd) *pp = mix(*pp, 0xFFFFFF, rim_a(i, j, w, h, (u32)rim) * bd / 255);
            if (gl) *pp = mix(*pp, 0xFFFFFF, rim_a(i, j, w, h, 46) * gl / 255);
        }
    }
}

static u32 bgclean[MAXW * MAXH]; static int bgclean_ok, dock_run[8], dock_nrun, dock_sig = -1;
/* The dock shows two fixed items (Terminal, This PC) plus ONLY the apps that are currently open. It is re-baked on the clean scene when that set changes. */
static void dock_bake(void) {
    if (bgclean_ok) { int band = (int)H - 100; if (band < 0) band = 0; memcpy(&bgbuf[band * W], &bgclean[band * W], ((int)H - band) * W * 4); }
    /* Floating glass dock. On narrow panels it pins fewer icons; Launchpad still exposes every app. */
    dock_apps_shown = dock_nrun;
    while (dock_apps_shown > 0 && (92 + 46 * (2 + dock_apps_shown) + 148) > (int)W - 20)
        dock_apps_shown--;
    { int need = 92 + 46 * (2 + dock_apps_shown) + 128;
      dkw = need + 20;
      if (dkw > (int)W - 20) dkw = (int)W - 20;
      if (dkw > 560 && need <= 540) dkw = 560;
    }
    dkh = 62; dkx = ((int)W - dkw) / 2; dky = (int)H - 78;
    for (int i = 0; i < 8; i++) draw_rr(bgbuf, dkx - i, dky - i + 8, dkw + 2 * i, dkh + 2 * i, 28 + i, 0x04101E, 6);
    glass(dkx, dky, dkw, dkh, 30, 0xAFC8FF, 58, 154, 245);
    int iy = dky + 11, ix = dkx + 10;
    draw_rr(bgbuf, ix - 1, iy - 1, 36, 36, 12, 0x6A72E8, 238);   /* original VinOS prism mark */
    draw_rr(bgbuf, ix + 2, iy + 2, 30, 30, 10, 0x35BFD8, 60);
    int cx = ix + 17, cy = iy + 17;
    draw_line(bgbuf, cx - 9, cy - 7, cx, cy + 8, 0xFFFFFF, 255);
    draw_line(bgbuf, cx, cy + 8, cx + 9, cy - 7, 0xFFFFFF, 255);
    draw_line(bgbuf, cx - 4, cy + 1, cx + 4, cy + 1, 0xC8F8FF, 235);
    ix += 58; dock_ix0 = ix;
    draw_rr(bgbuf, ix, iy, 34, 34, 10, 0x0D2238, 240); text(bgbuf, ix + 9, iy + 9, ">_", pal[A_ACC]);   /* terminal */
    ix += 46;
    draw_rr(bgbuf, ix, iy, 34, 34, 10, 0x1F4F78, 240);                                                 /* This PC */
    draw_rr(bgbuf, ix + 5, iy + 6, 24, 17, 4, 0x4BC2E8, 255); draw_line(bgbuf, ix + 8, iy + 20, ix + 25, iy + 10, 0xD6FBFF, 170);   /* This PC */
    draw_rr(bgbuf, ix + 14, iy + 23, 6, 4, 1, 0xDCEBFA, 255); draw_rr(bgbuf, ix + 9, iy + 27, 16, 3, 1, 0xDCEBFA, 255);
    if (dock_apps_shown) draw_line(bgbuf, ix + 63, iy + 4, ix + 63, iy + 30, 0xFFFFFF, 70);   /* separator: pinned | running */
    for (int ai = 0; ai < dock_apps_shown; ai++) { ix += 46; app_at(dock_run[ai] - 1)->icon(bgbuf, ix, iy); }
    {   /* power buttons: shutdown and restart, right next to the clock */
        int bx = dkx + dkw - 164, cx0, cy0 = iy + 17; const u32 W_ = 0xFFFFFF;
        draw_rr(bgbuf, bx, iy, 34, 34, 10, 0xA02A44, 255); cx0 = bx + 17;                         /* shutdown: ring with a bar */
        draw_rr(bgbuf, cx0 - 9, cy0 - 9, 19, 19, 9, W_, 255); draw_rr(bgbuf, cx0 - 7, cy0 - 7, 15, 15, 7, 0xA02A44, 255);
        draw_rr(bgbuf, cx0 - 3, cy0 - 10, 7, 8, 0, 0xA02A44, 255); draw_rr(bgbuf, cx0 - 1, cy0 - 10, 3, 11, 1, W_, 255);
        bx += 40; cx0 = bx + 17;
        draw_rr(bgbuf, bx, iy, 34, 34, 10, 0x2A6F9E, 255);                                         /* restart: circular arrow */
        draw_rr(bgbuf, cx0 - 9, cy0 - 9, 19, 19, 9, W_, 255); draw_rr(bgbuf, cx0 - 7, cy0 - 7, 15, 15, 7, 0x2A6F9E, 255);
        draw_rr(bgbuf, cx0 + 1, cy0 - 10, 10, 8, 0, 0x2A6F9E, 255);
        for (int k = 0; k < 6; k++) { int hh = 4 - (4 * k) / 6; draw_rr(bgbuf, cx0 - 1 + k, cy0 - 8 - hh, 1, 2 * hh + 1, 0, W_, 255); }
    }
}
static void dock_sync(int force) {
    int nr = 0, nl[8];
    for (int k = 0; k < dock_nrun; k++) if (win_find(dock_run[k]) >= 0) nl[nr++] = dock_run[k];
    for (int i = 0; i < nwin; i++) { int a = win_[i].app, f = 0; if (a == 7) continue; for (int k = 0; k < nr; k++) if (nl[k] == a) f = 1; if (!f && nr < 8) nl[nr++] = a; }
    int sig = nr; for (int k = 0; k < nr; k++) sig = sig * 31 + nl[k];
    if (force || sig != dock_sig || nr != dock_nrun) { for (int k = 0; k < nr; k++) dock_run[k] = nl[k]; dock_nrun = nr; dock_sig = sig; dock_bake(); }
}

static void build_scene(void) {
    paint_bg();
    memcpy(bgblur, bgbuf, W * H * 4); if (blur_r > 0) { blur_rect(bgblur, (int)W, (int)H, blur_r); lift(bgblur, (int)(W * H), 185, 30); }
    ww = (int)W - 80; if (ww > 1100) ww = 1100;
    wh = (int)H - 70 - 86;
    wx = ((int)W - ww) / 2; wy = 70;
    cols = (ww - 32) / 8; if (cols > COLS_MAX) cols = COLS_MAX;
    rows = (wh - 34 - 20) / 16; if (rows > ROWS_MAX) rows = ROWS_MAX;
    tx = wx + 16; ty = wy + 34 + 10;
    if (terminal_visible) {
        for (int i = 0; i < 14; i++) draw_rr(bgbuf, wx - i, wy - i + 14, ww + 2 * i, wh + 2 * i, 26 + i, 0x04101E, 5);
        glass(wx, wy, ww, wh, 26, WIN_TINT, win_alpha, 52, 200);
        for (int i = 0; i < ww - 2; i++) { u32 *p = &bgbuf[(wy + 33) * W + wx + 1 + i]; *p = mix(*p, 0xFFFFFF, 26); }
    }

    memcpy(bgclean, bgbuf, W * H * 4); bgclean_ok = 1;   /* wallpaper + panels + Terminal, no dock: the dock is re-baked on top of this when windows open/close */
    dock_sync(1);
}

/* ============================ terminal ============================ */
static char tc[ROWS_MAX][COLS_MAX]; static u8 ta_[ROWS_MAX][COLS_MAX];
static int cx_, cy_, dirty = 1, hide_cur;

static void t_clear(void) { memset(tc, ' ', sizeof tc); memset(ta_, 0, sizeof ta_); cx_ = cy_ = 0; dirty = 1; }
static void t_nl(void) {
    cx_ = 0;
    if (++cy_ >= rows) {
        cy_ = rows - 1;
        memmove(tc[0], tc[1], (unsigned)(ROWS_MAX - 1) * COLS_MAX); memmove(ta_[0], ta_[1], (unsigned)(ROWS_MAX - 1) * COLS_MAX);
        memset(tc[rows - 1], ' ', COLS_MAX); memset(ta_[rows - 1], 0, COLS_MAX);
    }
}
static void t_putc(char c, u8 a) {
    dirty = 1;
    if (c == '\n') { t_nl(); return; }
    if (c == '\t') { do t_putc(' ', a); while (cx_ % 4); return; }
    tc[cy_][cx_] = c; ta_[cy_][cx_] = a;
    if (++cx_ >= cols) t_nl();
}
static void t_puts(const char *s, u8 a) { while (*s) t_putc(*s++, a); }
static void t_say(const char *s, u8 a) { t_puts(s, a); t_putc('\n', a); }
static void t_pad2(int n) { t_putc('0' + (n / 10) % 10, A_TXT); t_putc('0' + n % 10, A_TXT); }
static void t_num(u32 n, int pad) {
    char b[12]; int i = 11; b[i] = 0; if (!n) b[--i] = '0';
    while (n) { b[--i] = '0' + n % 10; n /= 10; }
    int len = 11 - i; for (int k = len; k < pad; k++) t_putc(' ', A_TXT);
    t_puts(b + i, A_TXT);
}

/* ============================ dynamic island ============================ */
static int timer_on; static u32 timer_end;
static int iw = 112 << 8, ih = 34 << 8, vw, vh, tw = 112 << 8, th = 34 << 8;
static char isl_msg[64]; static int isl_kind, isl_expand; static u32 isl_until, cur_ms;
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }

static void idle_size(void) { tw = (timer_on ? 150 : 112) << 8; th = 34 << 8; }
static void notify(const char *m, int kind) {
    int i = 0; for (; m[i] && i < 56; i++) isl_msg[i] = m[i]; isl_msg[i] = 0;
    isl_kind = kind; isl_expand = 1; isl_until = cur_ms + 2400;
    int w = 52 + slen(isl_msg) * 8 + 24; if (w < 200) w = 200; if (w > (int)W - 40) w = (int)W - 40;
    tw = w << 8; th = 62 << 8; dirty = 1;
}
static int isl_moving(void) {
    int a = tw - iw, b = th - ih;
    return (a > 256 || a < -256 || b > 256 || b < -256 || vw > 64 || vw < -64 || vh > 64 || vh < -64);
}
static void isl_step(void) {                       /* damped spring: slight bounce, like the real thing */
    vw = ((vw + (tw - iw) / 8) * 7) / 10; iw += vw;
    vh = ((vh + (th - ih) / 8) * 7) / 10; ih += vh;
    if (!isl_moving()) { iw = tw; ih = th; vw = vh = 0; }
}
static void draw_island(u32 *buf, u32 ms) {
    if (!isl_expand && !timer_on) return; /* no empty capsule on an idle desktop */
    int w = iw >> 8, h = ih >> 8, x = (int)W - w - 22, y = (int)H - h - 86;
    int r = h / 2; if (r > 28) r = 28;
    draw_rr(buf, x - 3, y + 4, w + 6, h + 6, r + 3, 0x000000, 48);          /* soft card shadow */
    draw_rr(buf, x, y, w, h, r, 0x4AA7D8, 150);                             /* VinOS notification accent */
    draw_rr(buf, x + 1, y + 1, w - 2, h - 2, r > 1 ? r - 1 : 0, 0x102B49, 218);
    if (isl_expand && w >= (tw >> 8) - 30) {
        static const u32 kc[3] = {0x6FE3FF, 0x8FFFC4, 0xFF8FA3}; static const char kg[3] = {'i', '+', '!'};
        draw_rr(buf, x + 14, y + h / 2 - 14, 28, 28, 14, kc[isl_kind], 255);
        glyph(buf, x + 14 + 10, y + h / 2 - 8, kg[isl_kind], 0x04101E);
        text(buf, x + 52, y + h / 2 - 8, isl_msg, 0xF2FAFF);
    } else if (!isl_expand && w >= 100) {
        u32 pulse = ((ms / 700) & 1) ? 255 : 170;
        if (timer_on) {                                    /* live activity: countdown */
            u32 sec = ((timer_end > ms ? timer_end - ms : 0) + 999) / 1000; char b[16] = "Timer 00:00";
            b[6] = '0' + (sec / 60 / 10) % 10; b[7] = '0' + (sec / 60) % 10; b[9] = '0' + (sec % 60) / 10; b[10] = '0' + sec % 10;
            draw_rr(buf, x + 18, y + h / 2 - 4, 8, 8, 4, 0xFFB454, pulse);
            text(buf, x + 36, y + h / 2 - 8, b, 0xFFF0DC);
        } else {
            draw_rr(buf, x + 18, y + h / 2 - 4, 8, 8, 4, 0x6FE3FF, pulse);
            text(buf, x + 36, y + h / 2 - 8, "VinOS", 0xDCEEFA);
        }
    }
}

/* ============================ RAM file system ============================ */
#define NODES 96
#define FSIZE 2048
typedef struct { char name[24]; int parent; u8 used, isdir; int size; } Node;
static Node nd[NODES]; static char fdata[NODES][FSIZE]; static int cwd;
/* Standard user folders on C: (the current filesystem is RAM-backed, not a physical disk). */
static int home_node, desktop_node, documents_node, downloads_node, pictures_node, music_node, videos_node, projects_node;

static char lw(char c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
static int ci_eq(const char *a, const char *b) { while (*a && *b) { if (lw(*a) != lw(*b)) return 0; a++; b++; } return *a == *b; }
static void scpy(char *d, const char *s, int max) { int i = 0; for (; s[i] && i < max - 1; i++) d[i] = s[i]; d[i] = 0; }
static int fs_find(int dir, const char *n) {
    for (int i = 1; i < NODES; i++) if (nd[i].used && nd[i].parent == dir && ci_eq(nd[i].name, n)) return i;
    return -1;
}
static int valid_name(const char *n) {
    int l = slen(n); if (l < 1 || l > 23) return 0;
    for (int i = 0; i < l; i++) { char c = n[i]; if (c == '\\' || c == '/' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|') return 0; }
    return 1;
}
static int fs_new(int dir, const char *n, int isdir) {
    for (int i = 1; i < NODES; i++) if (!nd[i].used) {
        nd[i].used = 1; nd[i].isdir = (u8)isdir; nd[i].parent = dir; nd[i].size = 0; scpy(nd[i].name, n, 24); return i;
    }
    return -1;
}
static int resolve(const char *p) {
    int cur = cwd;
    if (p[0] && p[1] == ':') p += 2;
    if (*p == '\\' || *p == '/') { cur = 0; p++; }
    char seg[24];
    while (*p) {
        int n = 0; while (*p && *p != '\\' && *p != '/') { if (n < 23) seg[n++] = *p; p++; }
        seg[n] = 0; if (*p) p++;
        if (n == 0 || (n == 1 && seg[0] == '.')) continue;
        if (n == 2 && seg[0] == '.' && seg[1] == '.') { cur = nd[cur].parent < 0 ? 0 : nd[cur].parent; continue; }
        int idx = fs_find(cur, seg);
        if (idx < 0 || (!nd[idx].isdir && *p)) return -1;
        cur = idx;
    }
    return cur;
}
static int resolve_parent(const char *p, int *parent, char *leaf) {   /* split "dir\leaf" */
    char dir[96]; int l = slen(p), k = l;
    while (k > 0 && p[k - 1] != '\\' && p[k - 1] != '/') k--;
    scpy(leaf, p + k, 24);
    if (k == 0) { *parent = cwd; return 1; }
    int i = 0; for (; i < k && i < 95; i++) dir[i] = p[i]; dir[i] = 0;
    int d = resolve(dir); if (d < 0 || !nd[d].isdir) return 0;
    *parent = d; return 1;
}
static void node_path(int node, char *out) {
    int chain[8], n = 0, c = node;
    while (c > 0 && n < 8) { chain[n++] = c; c = nd[c].parent; }
    int o = 0; out[o++] = 'C'; out[o++] = ':'; out[o++] = '\\';
    for (int i = n - 1; i >= 0; i--) { for (const char *s = nd[chain[i]].name; *s; s++) out[o++] = *s; if (i) out[o++] = '\\'; }
    out[o] = 0;
}
static void path_str(char *out) { node_path(cwd, out); }
static void add_txt(char *leaf) {                      /* "notes" -> "notes.txt" */
    int l = slen(leaf), dot = 0; for (int i = 0; i < l; i++) if (leaf[i] == '.') dot = 1;
    if (!dot && l <= 19) { leaf[l] = '.'; leaf[l + 1] = 't'; leaf[l + 2] = 'x'; leaf[l + 3] = 't'; leaf[l + 4] = 0; }
}

/* ============================ text editor (Esc = save) ============================ */
static int ed_on, ed_node, ed_len; static char edbuf[FSIZE];
static void ed_draw(void) {
    t_clear();
    t_puts(" Editing ", A_DIM); t_puts(nd[ed_node].name, A_ACC); t_say("   -   type freely, Esc saves and closes", A_DIM);
    t_say(" ------------------------------------------------", A_DIM);
    for (int i = 0; i < ed_len; i++) t_putc(edbuf[i], A_TXT);
}
static void ed_begin(int idx) {
    ed_on = 1; ed_node = idx; ed_len = nd[idx].size; memcpy(edbuf, fdata[idx], (unsigned)ed_len); ed_draw();
}

/* ============================ shell ============================ */
static char line[256]; static int ll;
static char hist[8][256]; static int hn, hpos;
static int ntok; static char tk[16][64], tl[16][64]; static const char *trest[16];

static void prompt(void) {
    if (prompt_mode == 1) t_puts("> ", A_ACC);
    else if (prompt_mode == 2) { t_puts(prompt_txt, A_ACC); t_puts("> ", A_ACC); }
    else { char p[200]; path_str(p); t_puts(p, A_ACC); t_puts("> ", A_ACC); }
    ll = 0;
}
static void tokenize(const char *s) {
    ntok = 0;
    while (*s && ntok < 16) {
        while (*s == ' ') s++;
        if (!*s) break;
        trest[ntok] = s; int n = 0;
        while (*s && *s != ' ') { if (n < 63) { tk[ntok][n] = *s; tl[ntok][n] = lw(*s); n++; } s++; }
        tk[ntok][n] = tl[ntok][n] = 0; ntok++;
    }
}
static int is_(const char *w, const char *a, const char *b, const char *c, const char *d) {
    return ci_eq(w, a) || (b && ci_eq(w, b)) || (c && ci_eq(w, c)) || (d && ci_eq(w, d));
}
static void err(const char *m) { t_say(m, A_ERR); notify(m, 2); }

static void cmd_help(int page) {
    if (page == 1) {
        t_say(" TOOLS & FUN", A_ACC);
        t_say(" calc 2+3*(4-1)            integer calculator", A_TXT);
        t_say(" date                      date and time", A_TXT);
        t_say(" timer 90 | 5m | stop      countdown shown in the island", A_TXT);
        t_say(" theme prism|glacier|night|aurora|sunset|nebula", A_TXT);
        t_say(" snake                     game  (arrows or WASD, Esc quits)", A_TXT);
        t_say(" beep                      PC speaker alert check", A_TXT);
        t_say(" sysinfo | uptime | memory | history | about", A_TXT);
        t_say(" island TEXT               show text in the island", A_TXT);
        t_say(" restart | shutdown", A_TXT);
        return;
    }
    t_say(" FILES & FOLDERS      easy word / classic", A_ACC);
    t_say(" list                       dir", A_TXT);
    t_say(" go to NAME | go back       cd NAME | cd ..", A_TXT);
    t_say(" make folder NAME           md NAME", A_TXT);
    t_say(" make file NAME             edit NAME     (Esc saves)", A_TXT);
    t_say(" show NAME                  type NAME", A_TXT);
    t_say(" write NAME text            append NAME text", A_TXT);
    t_say(" echo text > NAME           (>> adds to the end)", A_TXT);
    t_say(" copy A B | move A B        rename A B", A_TXT);
    t_say(" delete NAME                del NAME", A_TXT);
    t_say(" tree | find TEXT           clear (cls)", A_TXT);
    t_say(" help tools  ->  calculator, timer, themes, snake and more", A_DIM);
}

/* ---- integer calculator ---- */
static const char *cp; static int cerr;
static int c_expr(void);
static void c_ws(void) { while (*cp == ' ') cp++; }
static int c_fac(void) {
    c_ws();
    if (*cp == '-') { cp++; return -c_fac(); }
    if (*cp == '(') { cp++; int v = c_expr(); c_ws(); if (*cp == ')') cp++; else cerr = 1; return v; }
    if (*cp >= '0' && *cp <= '9') { int v = 0; while (*cp >= '0' && *cp <= '9') { v = v * 10 + (*cp - '0'); cp++; } return v; }
    cerr = 1; return 0;
}
static int c_term(void) {
    int v = c_fac();
    for (;;) {
        c_ws(); char o = *cp;
        if (o == '*') { cp++; v *= c_fac(); }
        else if (o == '/' || o == '%') {
            cp++; int r = c_fac();
            if (!r) { cerr = 2; return 0; }
            if (r == -1) v = (o == '/') ? -v : 0; else v = (o == '/') ? v / r : v % r;
        } else return v;
    }
}
static int c_expr(void) {
    int v = c_term();
    for (;;) { c_ws(); char o = *cp; if (o == '+') { cp++; v += c_term(); } else if (o == '-') { cp++; v -= c_term(); } else return v; }
}
static void t_snum(int v) { if (v < 0) { t_putc('-', A_OK); t_num(0u - (u32)v, 0); } else t_num((u32)v, 0); }

static int ci_has(const char *hay, const char *nee) {
    for (; *hay; hay++) { const char *a = hay, *b = nee; while (*a && *b && lw(*a) == lw(*b)) { a++; b++; } if (!*b) return 1; }
    return 0;
}
static void tree_print(int dir, int depth) {
    for (int k = 1; k < NODES; k++) if (nd[k].used && nd[k].parent == dir) {
        for (int j = 0; j < depth; j++) t_puts("  ", A_DIM);
        t_puts(nd[k].isdir ? "+ " : "- ", A_DIM); t_say(nd[k].name, nd[k].isdir ? A_ACC : A_TXT);
        if (nd[k].isdir && depth < 8) tree_print(k, depth + 1);
    }
}
static int parse_dur(const char *p) {
    if (*p < '0' || *p > '9') return -1;
    int v = 0; while (*p >= '0' && *p <= '9') { v = v * 10 + (*p - '0'); p++; if (v > 100000) return -1; }
    if (*p == 'm' || *p == 'M') v *= 60; else if (*p == 'h' || *p == 'H') v *= 3600; else if (*p && *p != 's' && *p != 'S') return -1;
    return v;
}

/* ---- snake ---- */
static int game_on, gover, gw, gh, sl, sdx, sdy, fx, fy, score, spk_active;
static int sx[400], sy[400]; static u32 game_last, rng = 12345, spk_until;
static u32 rnd(void) { rng = rng * 1103515245u + 12345u; return (rng >> 16) & 0x7fff; }
static void gput(int x, int y, char ch, u8 a) { if (x >= 0 && y >= 0 && x < cols && y < rows) { tc[y][x] = ch; ta_[y][x] = a; } }
static void gstr(int x, int y, const char *t, u8 a) { for (; *t; t++, x++) gput(x, y, *t, a); }
static int game_ms(void) { int v = 130 - score * 3; return v < 60 ? 60 : v; }
static void game_draw(void) {
    t_clear(); hide_cur = 1;
    char hd[64] = " SNAKE   score 000   arrows/WASD move, Esc quits";
    hd[15] = '0' + (score / 100) % 10; hd[16] = '0' + (score / 10) % 10; hd[17] = '0' + score % 10;
    gstr(0, 0, hd, A_ACC);
    for (int x = 0; x <= gw + 1; x++) { gput(x, 1, (x == 0 || x == gw + 1) ? '+' : '-', A_DIM); gput(x, gh + 2, (x == 0 || x == gw + 1) ? '+' : '-', A_DIM); }
    for (int y = 0; y < gh; y++) { gput(0, y + 2, '|', A_DIM); gput(gw + 1, y + 2, '|', A_DIM); }
    gput(fx + 1, fy + 2, '*', A_ERR);
    for (int i = sl - 1; i >= 0; i--) gput(sx[i] + 1, sy[i] + 2, i ? 'o' : 'O', i ? A_OK : A_ACC);
    if (gover) gstr(gw / 2 - 12, gh / 2 + 2, "  GAME OVER - press any key  ", A_WARN);
}
static void game_food(void) {
    for (int tries = 0; tries < 500; tries++) {
        fx = (int)(rnd() % (u32)gw); fy = (int)(rnd() % (u32)gh); int ok = 1;
        for (int i = 0; i < sl; i++) if (sx[i] == fx && sy[i] == fy) ok = 0;
        if (ok) return;
    }
}
static void game_start(void) {
    gw = cols - 2; if (gw > 60) gw = 60; gh = rows - 4; if (gh > 22) gh = 22;
    sl = 4; for (int i = 0; i < sl; i++) { sx[i] = gw / 2 - i; sy[i] = gh / 2; }
    sdx = 1; sdy = 0; score = 0; gover = 0; game_on = 1; game_last = cur_ms; rng ^= cur_ms; game_food(); game_draw();
}
static void game_step(void) {
    int nx = sx[0] + sdx, ny = sy[0] + sdy;
    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) { gover = 1; }
    for (int i = 0; i < sl - 1 && !gover; i++) if (sx[i] == nx && sy[i] == ny) gover = 1;
    if (gover) { notify("Game over", 2); speaker_on(220); spk_active = 1; spk_until = cur_ms + 350; return; }
    int tx_ = sx[sl - 1], ty_ = sy[sl - 1];
    for (int i = sl - 1; i > 0; i--) { sx[i] = sx[i - 1]; sy[i] = sy[i - 1]; }
    sx[0] = nx; sy[0] = ny;
    if (nx == fx && ny == fy) {
        if (sl < 399) { sx[sl] = tx_; sy[sl] = ty_; sl++; }
        score++; game_food();
        if (score % 5 == 0) notify("Nice! Keep going", 1);
    }
}
static void game_exit(void) { game_on = 0; hide_cur = 0; t_clear(); prompt(); }
static void game_key(int k) {
    if (gover) { game_exit(); return; }
    if (k == 27) { game_exit(); return; }
    if ((k == KEY_UP || k == 'w' || k == 'W') && sdy != 1) { sdx = 0; sdy = -1; }
    else if ((k == KEY_DOWN || k == 's' || k == 'S') && sdy != -1) { sdx = 0; sdy = 1; }
    else if ((k == KEY_LEFT || k == 'a' || k == 'A') && sdx != 1) { sdx = -1; sdy = 0; }
    else if ((k == KEY_RIGHT || k == 'd' || k == 'D') && sdx != -1) { sdx = 1; sdy = 0; }
}

#include "cmds.h"
#include "apps.h"

/* Hardware facts are detected independently from drivers. This does not claim
 * that battery or codec control is implemented merely because a device exists. */
static int acpi_sum_ok(const volatile u8 *p, int n) {
    u8 sum = 0; for (int i = 0; i < n; i++) sum = (u8)(sum + p[i]); return sum == 0;
}
static void hardware_probe(void) {
    acpi_present = 0; audio_device_present = 0;
#ifdef HOSTTEST
    return;
#else
    /* ACPI RSDP search window: legacy BIOS region, 16-byte aligned. */
    for (u32 a = 0xE0000; a < 0x100000; a += 16) {
        const volatile u8 *p = (const volatile u8 *)a;
        if (p[0] != 'R' || p[1] != 'S' || p[2] != 'D' || p[3] != ' ' ||
            p[4] != 'P' || p[5] != 'T' || p[6] != 'R' || p[7] != ' ') continue;
        if (!acpi_sum_ok(p, 20)) continue;
        acpi_present = 1;
        if (p[15] >= 2) {
            u32 len = *(const volatile u32 *)(p + 20);
            if (len >= 36 && len <= 4096 && !acpi_sum_ok(p, (int)len)) acpi_present = 0;
        }
        if (acpi_present) break;
    }
    /* PCI base class 04 = multimedia/audio. This only detects the controller. */
    for (int bus = 0; bus < 8 && !audio_device_present; bus++)
        for (int dev = 0; dev < 32 && !audio_device_present; dev++)
            for (int fn = 0; fn < 8; fn++) {
                u32 id = pci_rd(bus, dev, fn, 0);
                if ((id & 0xFFFFu) == 0xFFFFu) { if (!fn) break; continue; }
                if ((pci_rd(bus, dev, fn, 8) >> 24) == 4) { audio_device_present = 1; break; }
                if (!fn && !(pci_rd(bus, dev, 0, 0x0C) & 0x800000u)) break;
            }
#endif
}

static void cmd_list(void) {
    char p[200]; path_str(p); t_puts(" Directory of ", A_DIM); t_say(p, A_ACC);
    int nf = 0, nd_ = 0;
    for (int i = 1; i < NODES; i++) if (nd[i].used && nd[i].parent == cwd) {
        if (nd[i].isdir) { t_puts("  <DIR>      ", A_ACC); t_say(nd[i].name, A_ACC); nd_++; }
        else { t_puts("  ", A_TXT); t_num((u32)nd[i].size, 6); t_puts(" B     ", A_TXT); t_say(nd[i].name, A_TXT); nf++; }
    }
    if (!nf && !nd_) t_say("  (empty)", A_DIM);
    t_puts("  ", A_DIM); t_num((u32)nf, 0); t_puts(" file(s), ", A_DIM); t_num((u32)nd_, 0); t_say(" folder(s)", A_DIM);
}

static void exec_line(const char *s) {
    expand_vars(s); tokenize(xl); if (!ntok) return;
    { const Cmd *cm = cmd_lookup(tl[0]);
      if (cm && cm->cat >= C_M1) { cur_desc = cm->desc; cur_name = cm->name; if (!run_cmd(cm->cat, tl[0])) t_say("(not implemented)", A_ERR); return; } }
    const char *c = tl[0]; int i = 1, kf = 0, kd = 0;
    for (int k = 0; k < 2 && i < ntok; k++) {              /* skip filler words: "make FOLDER x", "go TO x" */
        const char *w = tl[i];
        if (is_(w, "file", "files", "text", "note")) { kf = 1; i++; }
        else if (is_(w, "folder", "folders", "directory", "dir")) { kd = 1; i++; }
        else if (is_(w, "to", "the", "a", "into")) i++;
        else break;
    }
    const char *arg = i < ntok ? tk[i] : "";
    int has = i < ntok;

    if (is_(c, "help", "?", "commands", 0)) cmd_help(ci_eq(arg, "tools") || ci_eq(arg, "apps") || ci_eq(arg, "more") || ci_eq(arg, "2"));
    else if (is_(c, "dir", "ls", "list", 0) || (is_(c, "show", "see", 0, 0) && (kf || kd) && !has)) cmd_list();
    else if (is_(c, "cls", "clear", 0, 0)) { t_clear(); }
    else if (is_(c, "cd", "go", "goto", "chdir") || (is_(c, "open", 0, 0, 0) && has && resolve(arg) >= 0 && nd[resolve(arg)].isdir)) {
        if (!has) { char p[200]; path_str(p); t_say(p, A_ACC); return; }
        int d = ci_eq(arg, "back") ? resolve("..") : (ci_eq(arg, "root") || ci_eq(arg, "home")) ? 0 : resolve(arg);
        if (d < 0 || !nd[d].isdir) err("Folder not found"); else cwd = d;
    }
    else if (is_(c, "md", "mkdir", 0, 0) || (is_(c, "make", "new", "create", "add") && kd)) {
        int par; char leaf[24];
        if (!has) { t_say("Name the folder, e.g. make folder docs", A_WARN); return; }
        if (!resolve_parent(arg, &par, leaf) || !valid_name(leaf)) { err("Bad folder name"); return; }
        if (fs_find(par, leaf) >= 0) { err("Already exists"); return; }
        if (fs_new(par, leaf, 1) < 0) { err("Disk full"); return; }
        t_puts("Folder created: ", A_OK); t_say(leaf, A_TXT); notify("Folder created", 1);
    }
    else if (is_(c, "edit", "notepad", "write", "append") || is_(c, "make", "new", "create", "add")) {
        int par; char leaf[24];
        if (!has) { t_say("Name the file, e.g. make file notes", A_WARN); return; }
        if (!resolve_parent(arg, &par, leaf) || !valid_name(leaf)) { err("Bad file name"); return; }
        int app = ci_eq(c, "append"), quick = ci_eq(c, "write") || app;
        add_txt(leaf);
        int idx = fs_find(par, leaf);
        if (idx >= 0 && nd[idx].isdir) { err("That is a folder"); return; }
        if (idx < 0) { idx = fs_new(par, leaf, 0); if (idx < 0) { err("Disk full"); return; } }
        if (quick) {                                          /* write NAME text... */
            const char *rest = i + 1 < ntok ? trest[i + 1] : ""; int n = app ? nd[idx].size : 0, q = 0;
            if (n > FSIZE - 2) { err("File is full"); return; }
            while (rest[q] && n < FSIZE - 2) fdata[idx][n++] = rest[q++];
            fdata[idx][n++] = '\n'; nd[idx].size = n;
            t_puts("Saved ", A_OK); t_say(leaf, A_TXT); notify("Saved file", 1);
        } else ed_begin(idx);
    }
    else if (is_(c, "type", "cat", "read", "show") || is_(c, "open", "view", 0, 0)) {
        if (!has) { t_say("Which file?  e.g. show notes.txt", A_WARN); return; }
        int idx = resolve(arg);
        if (idx < 0) { char tmp[24]; int par; if (resolve_parent(arg, &par, tmp)) { add_txt(tmp); idx = fs_find(par, tmp); } }
        if (idx <= 0) { err("File not found"); return; }
        if (nd[idx].isdir) { err("That is a folder"); return; }
        if (!nd[idx].size) t_say("(empty file)", A_DIM);
        for (int k = 0; k < nd[idx].size; k++) t_putc(fdata[idx][k], A_TXT);
        if (cx_) t_putc('\n', A_TXT);
        notify("Opened file", 0);
    }
    else if (is_(c, "del", "rm", "delete", "remove") || ci_eq(c, "erase")) {
        if (!has) { t_say("Delete what?", A_WARN); return; }
        int idx = resolve(arg);
        if (idx <= 0) { err("Not found"); return; }
        if (nd[idx].isdir) for (int k = 1; k < NODES; k++) if (nd[k].used && nd[k].parent == idx) { err("Folder is not empty"); return; }
        nd[idx].used = 0; t_puts("Deleted ", A_OK); t_say(nd[idx].name, A_TXT); notify("Deleted", 1);
    }
    else if (is_(c, "ren", "rename", 0, 0)) {
        if (ntok < i + 2) { t_say("Usage: rename OLD NEW", A_WARN); return; }
        int idx = resolve(arg);
        if (idx <= 0) { err("Not found"); return; }
        if (!valid_name(tk[i + 1]) || fs_find(nd[idx].parent, tk[i + 1]) >= 0) { err("Bad or taken name"); return; }
        scpy(nd[idx].name, tk[i + 1], 24); t_say("Renamed", A_OK); notify("Renamed", 1);
    }
    else if (ci_eq(c, "echo")) {
        const char *p = trest[0] + 4; while (*p == ' ') p++;
        const char *gt = p; while (*gt && *gt != '>') gt++;
        if (!*gt) { t_say(p, A_TXT); return; }
        int appd = gt[1] == '>'; const char *t = gt + (appd ? 2 : 1); while (*t == ' ') t++;
        char tgt[64]; int n = 0; while (t[n] && t[n] != ' ' && n < 63) { tgt[n] = t[n]; n++; } tgt[n] = 0;
        int par; char leaf[24];
        if (!n || !resolve_parent(tgt, &par, leaf) || !valid_name(leaf)) { err("Echo into which file?"); return; }
        add_txt(leaf); int idx = fs_find(par, leaf);
        if (idx >= 0 && nd[idx].isdir) { err("That is a folder"); return; }
        if (idx < 0) { idx = fs_new(par, leaf, 0); if (idx < 0) { err("Disk full"); return; } }
        int len = (int)(gt - p); while (len > 0 && p[len - 1] == ' ') len--;
        int pos = appd ? nd[idx].size : 0;
        if (pos + len + 1 > FSIZE) { err("File is full"); return; }
        for (int q = 0; q < len; q++) fdata[idx][pos++] = p[q];
        fdata[idx][pos++] = '\n'; nd[idx].size = pos;
        t_puts("Saved ", A_OK); t_say(leaf, A_TXT); notify("Saved file", 1);
    }
    else if (is_(c, "copy", "cp", 0, 0) || ci_eq(c, "move")) {
        int mv = ci_eq(c, "move");
        if (ntok < i + 2) { t_say(mv ? "Usage: move FROM TO" : "Usage: copy FROM TO", A_WARN); return; }
        int src = resolve(arg);
        if (src <= 0 || (!mv && nd[src].isdir)) { err("Source not found"); return; }
        int dst = resolve(tk[i + 1]), par; char leaf[24];
        if (dst >= 0 && nd[dst].isdir) { par = dst; scpy(leaf, nd[src].name, 24); }
        else if (!resolve_parent(tk[i + 1], &par, leaf) || !valid_name(leaf)) { err("Bad destination"); return; }
        int e = fs_find(par, leaf);
        if (mv) {
            if (e >= 0) { err("Name already exists there"); return; }
            for (int a = par; a > 0; a = nd[a].parent) if (a == src) { err("Can't move a folder into itself"); return; }
            nd[src].parent = par; scpy(nd[src].name, leaf, 24); t_say("Moved", A_OK); notify("Moved", 1);
        } else {
            if (e == src) { err("Same file"); return; }
            if (e >= 0 && nd[e].isdir) { err("Destination is a folder"); return; }
            if (e < 0) { e = fs_new(par, leaf, 0); if (e < 0) { err("Disk full"); return; } }
            memcpy(fdata[e], fdata[src], (unsigned)nd[src].size); nd[e].size = nd[src].size;
            t_say("Copied", A_OK); notify("Copied", 1);
        }
    }
    else if (ci_eq(c, "tree")) {
        char p[200]; path_str(p); t_say(p, A_ACC); int any = 0;
        for (int k = 1; k < NODES; k++) if (nd[k].used && nd[k].parent == cwd) any = 1;
        if (!any) t_say("  (empty)", A_DIM); else tree_print(cwd, 0);
    }
    else if (ci_eq(c, "find") || ci_eq(c, "search")) {
        if (!has) { t_say("find TEXT  -  searches names everywhere", A_WARN); return; }
        int hit = 0;
        for (int k = 1; k < NODES; k++) if (nd[k].used && ci_has(nd[k].name, arg)) {
            char p[200]; node_path(k, p); t_say(p, nd[k].isdir ? A_ACC : A_TXT); hit++;
        }
        if (!hit) t_say("Nothing found", A_DIM);
    }
    else if (is_(c, "calc", "math", "calculate", 0)) {
        if (!has) { t_say("calc 2+3*(4-1)   -  whole numbers, + - * / % and ( )", A_WARN); return; }
        cp = trest[i]; cerr = 0; int v = c_expr(); c_ws(); if (*cp) cerr = 1;
        if (cerr == 2) err("Can't divide by zero");
        else if (cerr) err("That doesn't look like math");
        else { t_puts(" = ", A_DIM); t_snum(v); t_putc('\n', A_TXT); }
    }
    else if (is_(c, "date", "time", "clock", 0)) {
        int h, mi, sc, d, mo, y; rtc_read(&h, &mi, &sc, &d, &mo, &y);
        t_puts(" ", A_DIM); t_num((u32)y, 0); t_putc('-', A_DIM); t_pad2(mo); t_putc('-', A_DIM); t_pad2(d);
        t_puts("   ", A_DIM); t_pad2(h); t_putc(':', A_DIM); t_pad2(mi); t_putc(':', A_DIM); t_pad2(sc); t_putc('\n', A_TXT);
    }
    else if (ci_eq(c, "timer")) {
        if (has && is_(arg, "stop", "cancel", "off", "end")) {
            if (timer_on) { timer_on = 0; idle_size(); notify("Timer cancelled", 0); t_say("Timer cancelled", A_OK); } else t_say("No timer running", A_DIM);
        } else if (!has) {
            if (timer_on) { t_puts(" Time left: ", A_DIM); t_num((timer_end - cur_ms + 999) / 1000, 0); t_say(" sec", A_TXT); }
            else t_say("timer 90  |  timer 5m  |  timer stop", A_WARN);
        } else {
            int sec = parse_dur(arg);
            if (sec <= 0 || sec > 5999) { err(sec > 5999 ? "Max is 99 minutes" : "Try: timer 90 or timer 5m"); return; }
            timer_on = 1; timer_end = cur_ms + (u32)sec * 1000u; idle_size(); dirty = 1;
            t_puts(" Timer started: ", A_OK); t_num((u32)sec, 0); t_say(" sec  (watch the island)", A_DIM);
        }
    }
    else if (ci_eq(c, "theme") || ci_eq(c, "wallpaper")) {
        if (!has) {
            t_puts(" Themes:", A_DIM); for (int k = 0; k < THEME_COUNT; k++) { t_putc(' ', A_TXT); t_puts(themes[k].name, k == theme_i ? A_ACC : A_TXT); }
            t_putc('\n', A_TXT); return;
        }
        int f = -1; for (int k = 0; k < THEME_COUNT; k++) if (ci_eq(themes[k].name, arg)) f = k;
        if (f < 0) { err("Unknown theme"); return; }
        theme_i = f; build_scene(); dirty = 1; t_puts(" Theme: ", A_DIM); t_say(themes[f].name, A_ACC); notify("Theme applied", 1);
    }
    else if (ci_eq(c, "beep")) { if (alerts_enabled) { speaker_on(880); spk_active = 1; } spk_until = cur_ms + 250; t_say(" beep!", A_DIM); }
    else if (is_(c, "snake", "game", "play", 0)) { game_start(); }
    else if (ci_eq(c, "history")) {
        int from = hn > 8 ? hn - 8 : 0;
        if (hn == 0) t_say(" (nothing yet)", A_DIM);
        for (int k = from; k < hn; k++) { t_puts("  ", A_DIM); t_say(hist[k & 7], A_TXT); }
    }
    else if (is_(c, "sysinfo", "neofetch", "specs", 0)) {
        static const char *logo[8] = {"     /\\       ", "    /  \\  /\\  ", "   / /\\ \\/  \\ ", "  /_/  \\_\\__\\ ",
                                      "              ", "              ", "              ", "              "};
        int h, mi, sc, d, mo, y, files = 0; rtc_read(&h, &mi, &sc, &d, &mo, &y);
        for (int k = 1; k < NODES; k++) if (nd[k].used) files++;
        for (int k = 0; k < 8; k++) {
            t_puts(logo[k], A_ACC);
            switch (k) {
            case 0: t_say("VinOS 0.8", A_ACC); break;
            case 1: t_say("-----------------", A_DIM); break;
            case 2: t_puts("Screen  : ", A_DIM); t_num(W, 0); t_putc('x', A_TXT); t_num(H, 0); t_putc('\n', A_TXT); break;
            case 3: t_puts("Memory  : ", A_DIM); t_num(mem_kb / 1024, 0); t_say(" MB", A_TXT); break;
            case 4: t_puts("Uptime  : ", A_DIM); t_num(cur_ms / 60000, 0); t_say(" min", A_TXT); break;
            case 5: t_puts("Items   : ", A_DIM); t_num((u32)files, 0); t_say(" in RAM disk", A_TXT); break;
            case 6: t_puts("Theme   : ", A_DIM); t_say(themes[theme_i].name, A_TXT); break;
            default: t_puts("Time    : ", A_DIM); t_pad2(h); t_putc(':', A_TXT); t_pad2(mi); t_putc('\n', A_TXT); break;
            }
        }
    }
    else if (is_(c, "about", "ver", "info", "version")) {
        t_say(" VinOS 1.8  -  Desktop and This PC", A_ACC);
        t_say(" desktop icons, This PC, RAM drive, glass taskbar", A_DIM);
        notify("VinOS 0.8", 0);
    }
    else if (ci_eq(c, "uptime")) {
        u32 s = cur_ms / 1000; t_puts(" Up for ", A_DIM); t_num(s / 60, 0); t_puts(" min ", A_TXT); t_num(s % 60, 0); t_say(" sec", A_TXT);
    }
    else if (is_(c, "memory", "mem", "free", 0)) {
        int u = 0, b = 0; for (int k = 1; k < NODES; k++) if (nd[k].used) { u++; b += nd[k].size; }
        t_puts(" Items ", A_DIM); t_num((u32)u, 0); t_puts("/", A_DIM); t_num(NODES - 1, 0); t_puts("   bytes stored ", A_DIM); t_num((u32)b, 0); t_putc('\n', A_TXT);
    }
    else if (ci_eq(c, "island")) {
        if (!has) { t_say("island TEXT  -  shows TEXT in the notification card", A_WARN); return; }
        notify(trest[1], 0);
    }
    else if (is_(c, "shutdown", "off", "halt", "poweroff")) power_off();
    else if (is_(c, "restart", "reboot", 0, 0)) power_restart();
    else { t_puts("'", A_ERR); t_puts(tk[0], A_ERR); t_say("' is not a command. Try: help", A_ERR);
        const char *sg = suggest(tl[0]);
        if (sg) { t_puts(" Did you mean ", A_DIM); t_puts(sg, A_ACC); t_say(" ?", A_DIM); notify(sg, 0); } else notify("Unknown command", 2); }
}

static void ed_save(void) {
    memcpy(fdata[ed_node], edbuf, (unsigned)ed_len); nd[ed_node].size = ed_len; ed_on = 0;
    t_clear(); t_puts(" Saved ", A_OK); t_puts(nd[ed_node].name, A_TXT); t_puts("  (", A_DIM); t_num((u32)ed_len, 0); t_say(" bytes)", A_DIM);
    notify("Saved file", 1); prompt();
}

static void handle_key(int k) {
    dirty = 1;
    if (folder_prompt) {
        if (k == 27) { folder_prompt = 0; new_folder_len = 0; new_folder_name[0] = 0; return; }
        if (k == '\b') { if (new_folder_len) new_folder_name[--new_folder_len] = 0; return; }
        if (k == '\n') {
            int node = -1;
            if (valid_name(new_folder_name) && fs_find(desktop_node, new_folder_name) < 0) node = fs_new(desktop_node, new_folder_name, 1);
            if (node < 0) notify("Folder name invalid or disk full", 2); else notify("New folder created", 1);
            folder_prompt = 0; desk_menu_open = 0; new_folder_len = 0; new_folder_name[0] = 0; return;
        }
        if (k >= 32 && k < 127 && new_folder_len < 23) { new_folder_name[new_folder_len++] = (char)k; new_folder_name[new_folder_len] = 0; }
        return;
    }
    if (k == 27 && desk_menu_open) { desk_menu_open = 0; return; }
    if (gallery_open) { if (k == 27) gallery_open = 0; return; }
    if (k == KEY_SPOTLIGHT) {
        launcher_open = !launcher_open; launchpad_open = 0; control_open = 0;
        launcher_query[0] = 0; launcher_len = 0; return;
    }
    if (launchpad_open) { if (k == 27) launchpad_open = 0; return; }
    if (control_open) { if (k == 27) control_open = 0; return; }
    if (launcher_open) {
        if (k == 27) { launcher_open = 0; launcher_query[0] = 0; launcher_len = 0; return; }
        if (k == '\b') { if (launcher_len) launcher_query[--launcher_len] = 0; return; }
        if (k == '\n') {
            int found = -1;
            for (int i = 0; i < app_count(); i++) {
                const char *nm = app_at(i)->name; int a = 0, matched = 0;
                while (launcher_query[a]) {
                    int j = 0; while (nm[j] && nm[j] != launcher_query[a] && nm[j] != (char)(launcher_query[a] - 32)) j++;
                    if (!nm[j]) break; a++; nm += j + 1; matched++;
                }
                if (matched == launcher_len) { found = i; break; }
            }
            launcher_open = 0;
            if (found >= 0) { int rebuild = terminal_visible; terminal_visible = 0; if (rebuild) build_scene(); app_at(found)->open(); }
            else if (launcher_len) {
                if (ci_eq(launcher_query, "terminal")) focus_terminal();
                else { char cmd[64]; int z = 0; for (int j = 0; j < launcher_len && z < 62; j++) cmd[z++] = launcher_query[j]; cmd[z] = 0; run_in_terminal(cmd); }
            }
            launcher_query[0] = 0; launcher_len = 0; return;
        }
        if (k >= 32 && k < 127 && launcher_len < 46) { launcher_query[launcher_len++] = (char)k; launcher_query[launcher_len] = 0; }
        return;
    }
    if (k == KEY_ALTTAB) {                                   /* Alt+Tab: next window (or terminal <-> window) */
        win_cycle(); notify(app_on ? app_at(app_on - 1)->name : "Terminal", 0);
        return;
    }
    if (game_on) { game_key(k); return; }
    if (app_on) { app_key(k); return; }
    if (ed_on) {
        if (k == 27) ed_save();
        else if (k == '\b') { if (ed_len > 0) { ed_len--; ed_draw(); } }
        else if (k == '\n') { if (ed_len < FSIZE - 1) { edbuf[ed_len++] = '\n'; t_putc('\n', A_TXT); } }
        else if (k == '\t') { for (int n = 0; n < 4 && ed_len < FSIZE - 1; n++) { edbuf[ed_len++] = ' '; t_putc(' ', A_TXT); } }
        else if (k >= 32 && k < 127) { if (ed_len < FSIZE - 1) { edbuf[ed_len++] = (char)k; t_putc((char)k, A_TXT); } else notify("File is full", 2); }
        return;
    }
    if (!terminal_visible && !app_on && (k == '\n' || k == '\b' || (k >= 32 && k < 127))) focus_terminal();
    if (!terminal_visible && !app_on) return;
    if (k == '\n') {
        t_putc('\n', A_TXT); line[ll] = 0;
        if (ll) { scpy(hist[hn & 7], line, 256); hn++; }
        hpos = hn; exec_line(line);
        if (!ed_on) prompt();
    } else if (k == '\b') {
        if (ll > 0) { ll--; if (cx_ > 0) cx_--; else if (cy_ > 0) { cy_--; cx_ = cols - 1; } tc[cy_][cx_] = ' '; }
    } else if (k == KEY_UP || k == KEY_DOWN) {
        if (k == KEY_UP && hpos > 0 && hn - hpos < 8) hpos--; else if (k == KEY_DOWN && hpos < hn) hpos++; else return;
        while (ll > 0) { ll--; if (cx_ > 0) cx_--; else if (cy_ > 0) { cy_--; cx_ = cols - 1; } tc[cy_][cx_] = ' '; }
        if (hpos < hn) { const char *h = hist[hpos & 7]; for (; *h && ll < 250; h++) { line[ll++] = *h; t_putc(*h, A_TXT); } }
    } else if (k == '\t') { tab_complete();
    } else if (k >= 32 && k < 127 && ll < 250) { line[ll++] = (char)k; t_putc((char)k, A_TXT); }
}

/* ============================ frame ============================ */
static u32 prev[MAXW * MAXH]; static int prev_ok, cur_px = -1000, cur_py;
#ifndef HOSTTEST
static void cursor_restore(void) {       /* put back what the screen showed under the old cursor */
    if (cur_px < -500) return;
    for (int j = 0; j < CUR_H; j++) { int y = cur_py + j; if (y >= (int)H) break;
        for (int i = 0; i < CUR_W; i++) { int x = cur_px + i; if (x >= (int)W) break; if (cur_[j][i] != ' ') ((u32 *)((u8 *)fb + y * PITCH))[x] = prev[y * W + x]; } }
    cur_px = -1000;
}
static void cursor_paint(void) {
    for (int j = 0; j < CUR_H; j++) { int y = pmy + j; if (y >= (int)H) break;
        for (int i = 0; i < CUR_W; i++) { int x = pmx + i; if (x >= (int)W) break; char c = cur_[j][i]; if (c == ' ') continue; ((u32 *)((u8 *)fb + y * PITCH))[x] = c == 'X' ? 0x0A1020 : 0xFFFFFF; } }
    cur_px = pmx; cur_py = pmy;
}
static void cursor_sync(void) {          /* pointer moved: touch only ~100 pixels, never wait for a frame */
    if (!mouse_seen || !prev_ok || in_flip || (pmx == cur_px && pmy == cur_py)) return;
    cursor_restore(); cursor_paint();
}
static void flip(void) {                  /* write only the pixels that changed since the last frame */
    in_flip = 1;
    if (cur_px != pmx || cur_py != pmy || !mouse_seen) cursor_restore();   /* pointer sits still: leave it on screen (no flicker), just repaint it afterwards */
    for (u32 y = 0; y < H; y++) {
        u32 *p = back + y * W, *q = prev + y * W; u32 x0 = 0, x1 = W - 1;
        if (prev_ok) {
            while (x0 + 4 <= W && p[x0] == q[x0] && p[x0 + 1] == q[x0 + 1] && p[x0 + 2] == q[x0 + 2] && p[x0 + 3] == q[x0 + 3]) x0 += 4;
            while (x0 < W && p[x0] == q[x0]) x0++;
            if (x0 == W) continue;
            while (p[x1] == q[x1]) x1--;
        }
        memcpy((u8 *)fb + y * PITCH + x0 * 4, p + x0, (x1 - x0 + 1) * 4); memcpy(q + x0, p + x0, (x1 - x0 + 1) * 4);
        if ((y & 63) == 63) ps2_pump();                                         /* keep reading mouse bytes (pointer is repainted below) */
    }
    prev_ok = 1; in_flip = 0;
    if (mouse_seen) { if (cur_px != pmx || cur_py != pmy) cursor_restore(); cursor_paint(); }   /* pointer may have moved during the flip: clear the old spot too */
}
#else
static void flip(void) {}
static void cursor_sync(void) {}
#endif
/* VinOS menu bar: familiar desktop workflow, with its own mark, labels and status language. */
static int bar_day, bar_mon;
static void draw_system_bar(u32 *b, int hh, int mm) {
    char tm[6]; tm[0] = (char)('0' + (hh / 10) % 10); tm[1] = (char)('0' + hh % 10); tm[2] = ':';
    tm[3] = (char)('0' + (mm / 10) % 10); tm[4] = (char)('0' + mm % 10); tm[5] = 0;
    copy_rr(b, bgblur, 0, 0, (int)W, 38, 0);
    draw_rr(b, 0, 0, (int)W, 38, 0, 0x1C1C1E, 120);
    draw_rr(b, 0, 0, (int)W, 2, 0, 0xFFFFFF, 60);
    draw_line(b, 0, 37, (int)W - 1, 37, 0xD5E4FF, 124);
    glass_finish(b, 0, 0, (int)W, 38, 0, 86, 166);
    /* Original VinOS prism glyph. */
    draw_rr(b, 14, 7, 24, 24, 8, 0x657DEB, 238);
    draw_line(b, 19, 13, 26, 25, 0xFFFFFF, 255);
    draw_line(b, 26, 25, 33, 13, 0xFFFFFF, 255);
    draw_line(b, 22, 20, 30, 20, 0xB9F5FF, 235);
    text(b, 46, 12, "VinOS", 0xF7F5FF); text(b, 47, 12, "VinOS", 0xF7F5FF);   /* bold app-menu name, like a Mac menu bar */

    if (W < 1100) {
        /* Compact menu for small laptop panels. */
        text(b, 112, 12, "Apps", hot(106, 0, 52, 38) ? 0xB5F0FF : pal[A_TXT]);
        text(b, 170, 12, "Find", hot(164, 0, 54, 38) ? 0xB5F0FF : pal[A_TXT]);
        text(b, 230, 12, "Desk", hot(224, 0, 52, 38) ? 0xB5F0FF : pal[A_TXT]);
        hit_add(106, 0, 52, 38, 2001);
        hit_add(164, 0, 54, 38, 2002);
        hit_add(224, 0, 52, 38, 2000);
        int rx = (int)W - 190;
        draw_line(b, rx + 1, 17, rx + 7, 11, 0xE5F0FF, 230);
        draw_line(b, rx + 7, 11, rx + 13, 17, 0xE5F0FF, 230);
        draw_line(b, rx + 4, 20, rx + 7, 17, 0x92E7FF, 225);
        draw_line(b, rx + 7, 17, rx + 10, 20, 0x92E7FF, 225);
        draw_rr(b, rx + 6, 22, 3, 3, 1, 0x92E7FF, 255);
        draw_rr(b, rx + 52, 13, 5, 10, 2, 0xE5F0FF, 220);
        draw_line(b, rx + 58, 13, rx + 65, 9, 0xE5F0FF, 220);
        draw_line(b, rx + 58, 23, rx + 65, 27, 0xE5F0FF, 220);
        draw_rr(b, rx + 104, 13, 22, 12, 3, 0xDDEAFF, 180);
        draw_rr(b, rx + 126, 16, 3, 6, 1, 0xDDEAFF, 180);
        text(b, (int)W - 48, 12, tm, pal[A_TXT]);
        hit_add(rx, 0, 34, 38, 2004);
        hit_add(rx + 48, 0, 38, 38, 2004);
        hit_add(rx + 100, 0, 38, 38, 2004);
        hit_add((int)W - 54, 0, 54, 38, 2004);
        return;
    }

    draw_line(b, 94, 10, 94, 28, 0xC7D8FF, 60);
    text(b, 110, 12, "Desktop", hot(104, 0, 82, 38) ? 0xB5F0FF : pal[A_TXT]);
    text(b, 202, 12, "Apps", hot(194, 0, 48, 38) ? 0xB5F0FF : pal[A_TXT]);
    text(b, 258, 12, "Search", hot(250, 0, 54, 38) ? 0xB5F0FF : pal[A_TXT]);
    text(b, 314, 12, "Window", hot(306, 0, 72, 38) ? 0xB5F0FF : pal[A_TXT]);
    text(b, 394, 12, "Help", hot(386, 0, 52, 38) ? 0xB5F0FF : pal[A_TXT]);
    hit_add(104, 0, 82, 38, 2000);
    hit_add(194, 0, 48, 38, 2001);
    hit_add(250, 0, 60, 38, 2002);
    hit_add(306, 0, 72, 38, 2005);
    hit_add(386, 0, 52, 38, 2006);
    /* Status area never invents battery/network telemetry. */
    int rx = (int)W - 440;
    draw_line(b, rx + 1, 16, rx + 7, 10, 0xE5F0FF, 230);
    draw_line(b, rx + 7, 10, rx + 13, 16, 0xE5F0FF, 230);
    draw_line(b, rx + 4, 19, rx + 7, 16, 0x92E7FF, 225);
    draw_line(b, rx + 7, 16, rx + 10, 19, 0x92E7FF, 225);
    draw_rr(b, rx + 6, 21, 3, 3, 1, 0x92E7FF, 255);
    text(b, rx + 20, 12, "NET --", pal[A_DIM]);
    draw_rr(b, rx + 91, 13, 5, 10, 2, 0xE5F0FF, 220);
    draw_line(b, rx + 97, 13, rx + 104, 9, 0xE5F0FF, 220);
    draw_line(b, rx + 97, 23, rx + 104, 27, 0xE5F0FF, 220);
    text(b, rx + 110, 12, alerts_enabled ? "BEEP ON" : "MUTED", alerts_enabled ? pal[A_TXT] : pal[A_WARN]);
    draw_rr(b, rx + 190, 13, 22, 12, 3, 0xDDEAFF, 180);
    draw_rr(b, rx + 212, 16, 3, 6, 1, 0xDDEAFF, 180);
    text(b, rx + 220, 12, "BAT --", pal[A_DIM]);
    text(b, (int)W - 56, 12, tm, pal[A_TXT]);
    { static const char *mn_[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
      char dt[8]; int di = 0, mo = (bar_mon >= 1 && bar_mon <= 12) ? bar_mon - 1 : 0;
      if (bar_day >= 10) dt[di++] = (char)('0' + bar_day / 10);
      dt[di++] = (char)('0' + bar_day % 10); dt[di++] = ' '; dt[di] = 0;
      char full[12]; int fi = 0; for (int k = 0; dt[k]; k++) full[fi++] = dt[k]; for (int k = 0; k < 3; k++) full[fi++] = mn_[mo][k]; full[fi] = 0;
      if (bar_day >= 1) text(b, (int)W - 56 - 8 * (fi + 1), 12, full, pal[A_TXT]); }
    hit_add(rx + 84, 0, 108, 38, 2004);
    hit_add(rx + 184, 0, 112, 38, 2004);
    hit_add((int)W - 62, 0, 62, 38, 2004);
}

/* Desktop shortcuts: original VinOS vector artwork, with the wallpaper visible behind them. */
static void desk_folder_icon(u32 *b, int x, int y, u32 body) {
    draw_rr(b, x + 4, y + 5, 22, 10, 4, body, 255);
    draw_rr(b, x + 2, y + 10, 42, 29, 8, body, 248);
    draw_line(b, x + 7, y + 15, x + 38, y + 15, 0xFFFFFF, 68);
}
static void desk_pc_icon(u32 *b, int x, int y) {
    draw_rr(b, x + 3, y + 3, 42, 29, 7, 0x0A203A, 255);
    draw_rr(b, x + 6, y + 6, 36, 23, 4, 0x4BC2E8, 255);
    draw_line(b, x + 8, y + 23, x + 39, y + 10, 0xD6FBFF, 170);
    draw_rr(b, x + 21, y + 32, 7, 6, 2, 0xDCEBFA, 255);
    draw_rr(b, x + 13, y + 37, 23, 4, 2, 0xDCEBFA, 255);
}
static void desk_home_icon(u32 *b, int x, int y) {
    draw_line(b, x + 3, y + 20, x + 24, y + 3, 0xFFE3A0, 255);
    draw_line(b, x + 24, y + 3, x + 45, y + 20, 0xFFE3A0, 255);
    draw_rr(b, x + 8, y + 18, 32, 23, 5, 0xE9A95D, 255);
    draw_rr(b, x + 20, y + 26, 9, 15, 2, 0x6C4262, 255);
}
static void desk_drive_icon(u32 *b, int x, int y) {
    draw_rr(b, x + 2, y + 8, 44, 30, 8, 0xAFC9E8, 245);
    draw_rr(b, x + 5, y + 11, 38, 22, 5, 0x314A70, 255);
    draw_rr(b, x + 10, y + 26, 22, 3, 1, 0xAFC9E8, 210);
    draw_rr(b, x + 35, y + 25, 4, 4, 2, 0x7CFFC5, 255);
}
static void desk_file_icon(u32 *b, int x, int y, int kind) {
    desk_folder_icon(b, x, y, kind == 2 ? 0x4CACE9 : (kind == 3 ? 0x39B9A5 : 0x7D8FE7));
    if (kind == 2) {
        draw_rr(b, x + 17, y + 2, 16, 22, 3, 0xF3F7FF, 245);
        draw_line(b, x + 20, y + 8, x + 29, y + 8, 0x5284B8, 255);
        draw_line(b, x + 20, y + 13, x + 29, y + 13, 0x5284B8, 255);
    } else if (kind == 3) {
        draw_line(b, x + 24, y + 16, x + 24, y + 31, 0xFFFFFF, 255);
        draw_line(b, x + 18, y + 25, x + 24, y + 31, 0xFFFFFF, 255);
        draw_line(b, x + 24, y + 31, x + 30, y + 25, 0xFFFFFF, 255);
    } else {
        draw_line(b, x + 10, y + 29, x + 20, y + 20, 0xE7F7FF, 255);
        draw_line(b, x + 20, y + 20, x + 28, y + 26, 0xE7F7FF, 255);
        draw_line(b, x + 28, y + 26, x + 35, y + 18, 0xE7F7FF, 255);
    }
}
static void draw_desktop_icons(u32 *b) {
    static const char *labels[6] = {"This PC", "Home", "Documents", "Downloads", "Pictures", "RAM Disk (C:)"};
    int compact = (H < 560 || W < 760), cellw = compact ? 102 : 88, step = compact ? 88 : 76;
    int xbase = 18, ybase = 54;
    for (int i = 0; i < 6; i++) {
        int col = compact ? i / 3 : 0, row = compact ? i % 3 : i;
        int x = xbase + col * cellw, y = ybase + row * step;
        int over = hot(x, y, 66, 67);
        if (over) draw_rr(b, x - 5, y - 4, 76, 69, 12, 0xA9D9FF, 48);
        if (i == 0) desk_pc_icon(b, x + 8, y);
        else if (i == 1) desk_home_icon(b, x + 8, y);
        else if (i == 2) desk_file_icon(b, x + 8, y, 2);
        else if (i == 3) desk_file_icon(b, x + 8, y, 3);
        else if (i == 4) desk_file_icon(b, x + 8, y, 4);
        else desk_drive_icon(b, x + 8, y);
        if (i == 5) {
            text(b, x + 3, y + 46, "RAM Disk", 0x07172B); text(b, x + 3, y + 45, "RAM Disk", 0xF4F8FF);
            text(b, x + 23, y + 58, "(C:)", 0x07172B); text(b, x + 23, y + 57, "(C:)", 0xF4F8FF);
        } else {
            int tw = 8 * slen(labels[i]);
            text(b, x + (66 - tw) / 2, y + 47, labels[i], 0x07172B);
            text(b, x + (66 - tw) / 2, y + 46, labels[i], 0xF4F8FF);
        }
        hit_add(x - 4, y - 4, 74, 70, 3000 + i);
    }
    /* User-created desktop folders appear as real shortcuts. */
    { int slot = 0; for (int n = 1; n < NODES; n++) if (nd[n].used && nd[n].isdir && nd[n].parent == desktop_node) {
        int col = compact ? slot / 3 : 0, row = compact ? slot % 3 : 6 + slot;
        int x = xbase + col * cellw, y = ybase + row * step;
        desk_folder_icon(b, x + 8, y, 0xD7A95F);
        text(b, x + 3, y + 47, nd[n].name, 0x07172B); text(b, x + 3, y + 46, nd[n].name, 0xFFFFFF);
        hit_add(x - 4, y - 4, 74, 70, 3100 + n); slot++;
    } }
}

static void draw_control_center(u32 *b) {
    if (!control_open) return;
    int x = (int)W - 358, y = 46, w = 340, h = 332;
    copy_rr(b, bgblur, x, y, w, h, 24);
    draw_rr(b, x, y, w, h, 24, 0x3A3A3C, 110);
    glass_finish(b, x, y, w, h, 24, 164, 238);
    text(b, x + 20, y + 16, "QUICK CONTROLS", 0xF1F4FF);
    text(b, x + w - 30, y + 16, "x", pal[A_DIM]); hit_add(x + w - 40, y + 8, 30, 28, 2104);
    /* Network status tile. */
    draw_rr(b, x + 14, y + 44, w - 28, 55, 14, 0xFFFFFF, 34);
    text(b, x + 28, y + 54, "NETWORK", pal[A_ACC]);
    text(b, x + 28, y + 75, "No network driver loaded", pal[A_TXT]);
    /* Display control is a software framebuffer brightness adjustment. */
    draw_rr(b, x + 14, y + 109, w - 28, 74, 14, 0xFFFFFF, 34);
    text(b, x + 28, y + 120, "DISPLAY", pal[A_ACC]);
    { char v[8]; fmt_base((u32)display_level, 10, v); text(b, x + w - 72, y + 120, v, pal[A_TXT]); text(b, x + w - 72 + 8 * slen(v), y + 120, "%", pal[A_TXT]); }
    draw_rr(b, x + 28, y + 151, w - 120, 7, 4, 0x17284E, 180);
    draw_rr(b, x + 28, y + 151, (w - 120) * display_level / 100, 7, 4, 0x74DDF2, 245);
    draw_rr(b, x + w - 78, y + 141, 24, 24, 12, 0xFFFFFF, hot(x + w - 78, y + 141, 24, 24) ? 100 : 48);
    text(b, x + w - 72, y + 148, "-", pal[A_TXT]); hit_add(x + w - 78, y + 141, 24, 24, 2100);
    draw_rr(b, x + w - 48, y + 141, 24, 24, 12, 0xFFFFFF, hot(x + w - 48, y + 141, 24, 24) ? 100 : 48);
    text(b, x + w - 42, y + 148, "+", pal[A_TXT]); hit_add(x + w - 48, y + 141, 24, 24, 2101);
    /* Honest battery / charging status: never render a guessed percentage. */
    draw_rr(b, x + 14, y + 193, w - 28, 48, 14, 0xFFFFFF, 34);
    text(b, x + 28, y + 202, "BATTERY & CHARGING", pal[A_ACC]);
    text(b, x + 28, y + 220, acpi_present ? "ACPI found; battery driver not ready" : "Battery status unavailable", pal[A_TXT]);
    /* The sound driver currently drives the legacy PC speaker for short alerts only. */
    draw_rr(b, x + 14, y + 251, w - 28, 62, 14, 0xFFFFFF, 34);
    text(b, x + 28, y + 260, "SOUND ALERTS", pal[A_ACC]);
    text(b, x + 28, y + 279, alerts_enabled ? "PC speaker alerts enabled" : "PC speaker alerts muted", pal[A_TXT]);
    text(b, x + 28, y + 297, audio_device_present ? "PCI audio found; mixer driver pending" : "No PCI audio device detected", pal[A_DIM]);
    draw_rr(b, x + w - 82, y + 270, 54, 28, 12, alerts_enabled ? 0x318E9A : 0x647A91, 190);
    text(b, x + w - 70, y + 279, alerts_enabled ? "ON" : "OFF", 0xFFFFFF);
    hit_add(x + w - 82, y + 270, 54, 28, 2102);
}

/* Desktop glass dashboard: keeps the real desktop shortcuts visible while surfacing
 * the VinOS workspace, app shortcuts, Spotlight search and quick controls at a glance. */
static void draw_desktop_dashboard(u32 *b) {
    if (terminal_visible || launcher_open || launchpad_open || control_open) return;
    for (int i = 0; i < nwin; i++) if (!win_[i].min) return;

    int split = W >= 1200 && H >= 620;
    int px = 112, py = H >= 620 ? 112 : 86;
    int pw = split ? 700 : (int)W - 130;
    if (pw > 850) pw = 850;
    if (pw < 360) pw = (int)W - 120;
    if (pw < 300) return;

    /* Search is always visible, and clicking it opens the same Spotlight command palette
       as Win+Space. */
    int sx = px + 8, sy = 48, sw = pw - 16;
    if (sw > 520) sw = 520;
    if (sw > 0 && sy + 42 < (int)H) {
        copy_rr(b, bgblur, sx, sy, sw, 42, 18);
        draw_rr(b, sx, sy, sw, 42, 18, 0x636366, 90);
        glass_finish(b, sx, sy, sw, 42, 18, 140, 232);
        draw_rr(b, sx + 16, sy + 12, 14, 14, 7, 0xE9F7FF, 220);
        draw_rr(b, sx + 19, sy + 15, 8, 8, 4, 0x425A91, 240);
        draw_line(b, sx + 28, sy + 26, sx + 34, sy + 32, 0xE9F7FF, 235);
        text(b, sx + 46, sy + 16, "Search apps, settings and files", 0xF4F7FF);
        if (sw > 330) {
            draw_rr(b, sx + sw - 104, sy + 9, 92, 24, 10, 0xFFFFFF, 35);
            text(b, sx + sw - 94, sy + 17, "WIN + SPACE", 0xECF4FF);
        }
        hit_add(sx, sy, sw, 42, 2002);
    }

    /* App shelf. Terminal is included alongside every app in the registry. */
    int total = app_count() + 1;
    int grid_cols = pw >= 680 ? 4 : (pw >= 470 ? 3 : 2);
    int grid_rows = (total + grid_cols - 1) / grid_cols;
    int row_h = H >= 700 ? 94 : (H >= 580 ? 78 : 62);
    int panel_h = 54 + grid_rows * row_h + 14;
    int max_bottom = (int)dky - 14;
    int max_h = max_bottom - py;
    if (panel_h > max_h && grid_rows > 0) {
        row_h = (max_h - 68) / grid_rows;
        if (row_h < 38) row_h = 38;
        panel_h = 54 + grid_rows * row_h + 14;
    }
    if (panel_h > max_h) panel_h = max_h;
    if (panel_h < 94) return;
    copy_rr(b, bgblur, px, py, pw, panel_h, 24);
    draw_rr(b, px, py, pw, panel_h, 24, 0x3A3A3C, 120);
    glass_finish(b, px, py, pw, panel_h, 24, 164, 242);
    text(b, px + 20, py + 17, "VINOS WORKSPACE", 0xF2F6FF);
    text(b, px + 20, py + 36, "Your apps, ready when you are", 0xD4E5FF);
    int allx = px + pw - 108;
    draw_rr(b, allx, py + 12, 92, 28, 12, 0xFFFFFF, hot(allx, py + 12, 92, 28) ? 78 : 38);
    text(b, allx + 16, py + 22, "APP LIBRARY", 0xF4F7FF);
    hit_add(allx, py + 12, 92, 28, 2001);

    int grid_y = py + 52;
    int cell_w = (pw - 28) / grid_cols;
    for (int i = 0; i < total; i++) {
        int col = i % grid_cols, row = i / grid_cols;
        int cx = px + 14 + col * cell_w, cy = grid_y + row * row_h;
        int cw = cell_w - 6, ch = row_h - 4;
        int compact = row_h < 68;
        draw_rr(b, cx, cy, cw, ch, 14, 0xFFFFFF, hot(cx, cy, cw, ch) ? 78 : 28);
        const char *nm = i == 0 ? "Terminal" : app_at(i - 1)->name;
        if (compact) {
            int iy = cy + (ch - 24) / 2;
            u32 ac = (u32[]){0x183B5B,0x2D7FD3,0xD56A84,0x2B7890,0x5566A0,0xB58A45,0x3D9C8C,0x7256A8,0x70869A,0x3A789E,0x53678C}[i % 11];
            draw_rr(b, cx + 10, iy, 24, 24, 8, ac, 240);
            if (i == 0) text(b, cx + 13, iy + 8, ">_", 0xE9F7FF);
            else text(b, cx + 18, iy + 8, nm, 0xFFFFFF);
            text(b, cx + 44, cy + (ch - 8) / 2, nm, 0xF4F7FF);
        } else {
            int iy = cy + (row_h >= 82 ? 10 : 5);
            int ix = cx + (cw - 34) / 2;
            if (i == 0) {
                draw_rr(b, ix, iy, 34, 34, 10, 0x0D2238, 250);
                text(b, ix + 6, iy + 11, ">_", 0x8FE5FF);
            } else app_at(i - 1)->icon(b, ix, iy);
            int label_y = cy + ch - 20;
            int tw = 8 * slen(nm);
            text(b, cx + (cw - tw) / 2, label_y, nm, 0xF4F7FF);
        }
        hit_add(cx, cy, cw, ch, 1700 + i);
    }

    /* Persistent quick-status card, only on wider VAIO-style displays. */
    if (split) {
        int x = px + pw + 14, y = py, w = (int)W - x - 16, h = 358;
        if (w >= 300) {
            copy_rr(b, bgblur, x, y, w, h, 24);
            draw_rr(b, x, y, w, h, 24, 0x3A3A3C, 120);
            glass_finish(b, x, y, w, h, 24, 160, 240);
            text(b, x + 18, y + 17, "CONTROL CENTER", 0xF3F6FF);
            text(b, x + w - 104, y + 18, "OPEN  >", 0xCFE7FF);
            hit_add(x + w - 112, y + 8, 104, 30, 2004);

            int tilew = (w - 42) / 2;
            draw_rr(b, x + 14, y + 48, tilew, 58, 14, 0xFFFFFF, 38);
            text(b, x + 26, y + 60, "NETWORK", 0xBFEAFF);
            text(b, x + 26, y + 82, "Driver pending", 0xF5F7FF);
            draw_rr(b, x + 28 + tilew, y + 48, tilew, 58, 14, 0xFFFFFF, 38);
            text(b, x + 40 + tilew, y + 60, "SOUND ALERTS", 0xBFEAFF);
            text(b, x + 40 + tilew, y + 82, alerts_enabled ? "PC speaker: ON" : "PC speaker: OFF", 0xF5F7FF);
            hit_add(x + 28 + tilew, y + 48, tilew, 58, 2102);

            draw_rr(b, x + 14, y + 118, w - 28, 82, 15, 0xFFFFFF, 36);
            text(b, x + 28, y + 130, "DISPLAY BRIGHTNESS", 0xBFEAFF);
            { char v[8], pct[10]; fmt_base((u32)display_level, 10, v); scpy(pct, v, 10); int pn = slen(pct); pct[pn++] = '%'; pct[pn] = 0; text(b, x + w - 76, y + 130, pct, 0xF5F7FF); }
            draw_rr(b, x + 28, y + 160, w - 122, 7, 4, 0x142A52, 190);
            draw_rr(b, x + 28, y + 160, (w - 122) * display_level / 100, 7, 4, 0x7CE8F6, 245);
            draw_rr(b, x + w - 78, y + 148, 22, 24, 11, 0xFFFFFF, hot(x + w - 78, y + 148, 22, 24) ? 96 : 48);
            text(b, x + w - 72, y + 156, "-", 0xF5F7FF); hit_add(x + w - 78, y + 148, 22, 24, 2100);
            draw_rr(b, x + w - 48, y + 148, 22, 24, 11, 0xFFFFFF, hot(x + w - 48, y + 148, 22, 24) ? 96 : 48);
            text(b, x + w - 42, y + 156, "+", 0xF5F7FF); hit_add(x + w - 48, y + 148, 22, 24, 2101);

            draw_rr(b, x + 14, y + 211, w - 28, 56, 14, 0xFFFFFF, 36);
            text(b, x + 28, y + 222, "BATTERY & CHARGING", 0xBFEAFF);
            text(b, x + 28, y + 242, acpi_present ? "ACPI found; battery driver not ready" : "Battery data not available", 0xF5F7FF);
            draw_rr(b, x + 14, y + 279, w - 28, 48, 14, 0xFFFFFF, 26);
            text(b, x + 28, y + 289, "MORE SETTINGS", 0xBFEAFF);
            text(b, x + 28, y + 307, "Themes, windows and devices", 0xF5F7FF);
            hit_add(x + 14, y + 279, w - 28, 48, 2004);
        }
    }
}

static void draw_launchpad(u32 *b) {
    if (!launchpad_open) return;
    /* Terminal plus every built-in app; fit the grid to the detected panel. */
    int total = app_count() + 1;
    int grid_cols = W >= 1050 ? 4 : (W >= 700 ? 3 : 2);
    int grid_rows = (total + grid_cols - 1) / grid_cols;
    int panel_w = (int)W - 24; if (panel_w > 660) panel_w = 660;
    int cell_w = (panel_w - 32) / grid_cols;
    int row_h = H >= 700 ? 98 : (H >= 580 ? 82 : (H >= 520 ? 70 : 54));
    int panel_h = 54 + grid_rows * row_h + 18;
    if (panel_h > (int)H - 46) {
        row_h = ((int)H - 72) / grid_rows;
        if (row_h < 50) row_h = 50;
        panel_h = 54 + grid_rows * row_h + 18;
    }
    int x = ((int)W - panel_w) / 2;
    int y = ((int)H - panel_h) / 2;
    if (y < 40) y = 40;
    if (y + panel_h > (int)H - 8) y = (int)H - panel_h - 8;
    if (y < 0) y = 0;
    copy_rr(b, bgblur, x, y, panel_w, panel_h, 24);
    draw_rr(b, x, y, panel_w, panel_h, 24, 0x2C2C2E, 150);
    glass_finish(b, x, y, panel_w, panel_h, 24, 142, 228);
    text(b, x + 22, y + 18, "VINOS APP LIBRARY", 0xDDF5FF);
    text(b, x + panel_w - 168, y + 18, "All apps  |  Esc closes", pal[A_DIM]);
    for (int i = 0; i < total; i++) {
        int col = i % grid_cols, row = i / grid_cols;
        int tx0 = x + 16 + col * cell_w, ty0 = y + 48 + row * row_h;
        int tw = cell_w - 8, th = row_h - 6;
        draw_rr(b, tx0, ty0, tw, th, 13, 0xFFFFFF, hot(tx0, ty0, tw, th) ? 66 : 20);
        const char *nm = i == 0 ? "Terminal" : app_at(i - 1)->name;
        int iy = ty0 + (row_h >= 70 ? 7 : 4);
        int ix = tx0 + (tw - 34) / 2;
        if (i == 0) {
            draw_rr(b, ix, iy, 34, 34, 10, 0x0D2238, 250);
            text(b, ix + 6, iy + 11, ">_", 0x8FE5FF);
        } else app_at(i - 1)->icon(b, ix, iy);
        text(b, tx0 + (tw - 8 * slen(nm)) / 2, ty0 + row_h - 20, nm, pal[A_TXT]);
        hit_add(tx0, ty0, tw, th, 1700 + i);
    }
}

static void apply_brightness(u32 *b) {
    if (display_level >= 100) return;
    int n = (int)(W * H);
    for (int i = 0; i < n; i++) {
        u32 c = b[i]; int r = ((c >> 16) & 255) * display_level / 100;
        int g = ((c >> 8) & 255) * display_level / 100, bl = (c & 255) * display_level / 100;
        b[i] = ((u32)r << 16) | ((u32)g << 8) | (u32)bl;
    }
}

static void draw_desktop_context(u32 *b) {
    if (desk_menu_open) {
        int x = desk_menu_x, y = desk_menu_y, w = 190, h = 126;
        if (x + w > (int)W) x = (int)W - w - 4; if (y + h > (int)H) y = (int)H - h - 4;
        copy_rr(b, bgblur, x, y, w, h, 12); draw_rr(b, x, y, w, h, 12, 0x2C2C2E, 232); glass_finish(b, x, y, w, h, 12, 150, 230);
        text(b, x + 14, y + 12, "DESKTOP", 0xA9DDFB);
        text(b, x + 14, y + 36, "+  New Folder", 0xFFFFFF); hit_add(x + 4, y + 29, w - 8, 26, 2200);
        text(b, x + 14, y + 63, "  Gallery", 0xFFFFFF); hit_add(x + 4, y + 56, w - 8, 26, 2201);
        text(b, x + 14, y + 90, "  Personalize", 0xFFFFFF); hit_add(x + 4, y + 83, w - 8, 26, 2202);
    }
    if (folder_prompt) {
        int x = ((int)W - 340) / 2, y = ((int)H - 120) / 2;
        copy_rr(b, bgblur, x, y, 340, 120, 18); draw_rr(b, x, y, 340, 120, 18, 0x2C2C2E, 236); glass_finish(b, x, y, 340, 120, 18, 160, 235);
        text(b, x + 20, y + 18, "CREATE NEW FOLDER", 0xC7ECFF);
        draw_rr(b, x + 18, y + 48, 304, 34, 9, 0xFFFFFF, 52);
        text(b, x + 30, y + 59, new_folder_name[0] ? new_folder_name : "Type a folder name...", 0xFFFFFF);
        text(b, x + 20, y + 94, "Enter: create     Esc: cancel", 0xB7C9E2);
    }
    if (gallery_open) {
        int x = 110, y = 76, w = (int)W - 220, h = (int)H - 150; if (w < 300) { x = 12; w = (int)W - 24; } if (h < 180) { y = 42; h = (int)H - 54; }
        copy_rr(b, bgblur, x, y, w, h, 20); draw_rr(b, x, y, w, h, 20, 0x242426, 232); glass_finish(b, x, y, w, h, 20, 160, 235);
        text(b, x + 20, y + 18, "VINOS GALLERY  -  Pictures", 0xDDF5FF); text(b, x + w - 110, y + 18, "Esc to close", 0xD3E5FA);
        int count = 0; for (int n = 1; n < NODES; n++) if (nd[n].used && nd[n].parent == pictures_node && !nd[n].isdir) {
            int cx = x + 20 + (count % 4) * ((w - 40) / 4), cy = y + 54 + (count / 4) * 82;
            draw_rr(b, cx, cy, 66, 54, 9, (count & 1) ? 0x55A9C9 : 0x806BC2, 220);
            draw_line(b, cx + 8, cy + 40, cx + 28, cy + 20, 0xFFFFFF, 190); draw_line(b, cx + 28, cy + 20, cx + 48, cy + 39, 0xFFFFFF, 190);
            text(b, cx, cy + 60, nd[n].name, 0xFFFFFF); count++;
        }
        if (!count) text(b, x + 22, y + 72, "Your Pictures folder is empty. Add images in Files to see them here.", 0xE4ECFA);
    }
}

static void compose(u32 ms) {
    ps2_pump(); task_sync(); dock_sync(0);
    for (u32 y = 0; y < H; y += 96) { u32 n = H - y < 96 ? H - y : 96; memcpy(back + y * W, bgbuf + y * W, n * W * 4); ps2_pump(); }
    nhits = 0;
    if (!terminal_visible) draw_desktop_icons(back);
    if (terminal_visible) {
        text(back, wx + (ww - 8 * slen(wtitle)) / 2, wy + 9, wtitle, pal[A_DIM]);
        traffic_lights(back, wx, wy, !nwin || term_focus, 0);
        hit_add(wx + 10, wy + 5, 20, 22, 10); hit_add(wx + 32, wy + 5, 20, 22, 11);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) { char ch = tc[r][c]; if (ch > 32) glyph(back, tx + c * 8, ty + r * 16, ch, pal[ta_[r][c]]); }
            if ((r & 7) == 7) ps2_pump();
        }
        if ((!nwin || term_focus) && !hide_cur && !dock_hidden() && (ms / 500) % 2 == 0) draw_rr(back, tx + cx_ * 8, ty + cy_ * 16 + 1, 8, 14, 2, 0x6FE3FF, 210);
    }
    app_fast = 0;
    static int last_s = -1, rh, rm, rs, rd, rmo, ry;
    if ((int)(ms / 1000) != last_s) { last_s = (int)(ms / 1000); rtc_read(&rh, &rm, &rs, &rd, &rmo, &ry); bar_day = rd; bar_mon = rmo; }
    char clk[9] = "00:00:00";
    clk[0] = '0' + (rh / 10) % 10; clk[1] = '0' + rh % 10; clk[3] = '0' + (rm / 10) % 10; clk[4] = '0' + rm % 10;
    clk[6] = '0' + (rs / 10) % 10; clk[7] = '0' + rs % 10;

    draw_desktop_dashboard(back);
    wins_draw(back, ms);
    int dock_vis = !dock_hidden() || dock_peek;
    if (dock_vis) {
        if (dock_hidden()) dock_overlay(back);
        { int tf = !nwin || term_focus; draw_rr(back, dock_ix0 + 9, dky + dkh - 5, 16, 3, 1, 0xFFFFFF, tf ? 230 : 90); }
        { int pi = win_find(7); if (pi >= 0) draw_rr(back, dock_ix0 + 46 + 9, dky + dkh - 5, 16, 3, 1, 0xFFFFFF, win_[pi].min ? 60 : ((pi == nwin - 1 && !term_focus) ? 230 : 110)); }
        for (int k = 0; k < dock_apps_shown; k++) { int i = win_find(dock_run[k]); if (i >= 0) draw_rr(back, dock_ix0 + (2 + k) * 46 + 9, dky + dkh - 5, 16, 3, 1, 0xFFFFFF, win_[i].min ? 60 : ((i == nwin - 1 && !term_focus) ? 230 : 110)); }
        int iy = dky + 11; hit_add(dkx + 10, iy, 34, 34, 1);
        for (int i = 0; i < 2 + dock_apps_shown; i++) hit_add(dock_ix0 + i * 46, iy, 34, 34, i < 2 ? 2 + i : 500 + (dock_run[i - 2] - 1));
        if (hot(dkx + 10, iy, 34, 34)) draw_rr(back, dkx + 7, iy - 3, 40, 40, 17, 0xFFFFFF, 50);
        for (int i = 0; i < 2 + dock_apps_shown; i++) if (hot(dock_ix0 + i * 46, iy, 34, 34)) {
            int pulse = 28 + tri((int)(ms / 3), 100) * 2;
            draw_rr(back, dock_ix0 + i * 46 - 4, iy - 4, 42, 42, 14, 0x8FE5FF, (u32)pulse);
            const char *tip = i == 0 ? "Terminal" : (i == 1 ? "This PC" : app_at(dock_run[i - 2] - 1)->name);
            int tw = slen(tip) * 8 + 20, tx0 = dock_ix0 + i * 46 + 17 - tw / 2;
            draw_rr(back, tx0, dky - 30, tw, 22, 9, 0x071426, 210);
            text(back, tx0 + 10, dky - 23, tip, 0xE6F4FF);
        }
        { int by = dky + 11, bx[2] = {dkx + dkw - 164, dkx + dkw - 124}, bid[2] = {PWR_OFF_ID, PWR_RST_ID};
          for (int i = 0; i < 2; i++) {
              hit_add(bx[i], by, 34, 34, bid[i]);
              int armed = pwr_arm == bid[i] && ms < pwr_until;
              if (armed || hot(bx[i], by, 34, 34)) draw_rr(back, bx[i] - 3, by - 3, 40, 40, 13, 0xFFFFFF, armed ? 95 : 50);
          } }
        text(back, dkx + dkw - 16 - 64, dky + 22, clk, themes[theme_i].clk);
    }
    if (launcher_open) {
        int pw = 520, ph = 460, px = ((int)W - pw) / 2, py = ((int)H - ph) / 2 - 25;
        draw_rr(back, px - 8, py - 8, pw + 16, ph + 16, 25, 0x061426, 116);
        copy_rr(back, bgblur, px, py, pw, ph, 22);
        draw_rr(back, px, py, pw, ph, 22, 0x2C2C2E, 160);
        glass_finish(back, px, py, pw, ph, 22, 152, 236);
        draw_rr(back, px + 18, py + 18, pw - 36, 48, 14, 0xFFFFFF, 54);
        draw_rr(back, px + 18, py + 18, pw - 36, 48, 14, pal[A_ACC], 25);
        text(back, px + 34, py + 35, "Search apps or enter a terminal command", pal[A_DIM]);
        if (launcher_len) text(back, px + 34, py + 35, launcher_query, pal[A_TXT]);
        draw_rr(back, px + 18 + (launcher_len ? launcher_len : 24) * 8, py + 35, 7, 14, 1, pal[A_ACC], 230);
        text(back, px + 22, py + 82, "APPLICATIONS", pal[A_ACC]);
        for (int i = 0; i < app_count() && i < 10; i++) {
            int yy = py + 104 + i * 30;
            draw_rr(back, px + 18, yy, pw - 36, 26, 8, 0xFFFFFF, hot(px + 18, yy, pw - 36, 26) ? 50 : 12);
            app_at(i)->icon(back, px + 28, yy - 4);
            text(back, px + 76, yy + 6, app_at(i)->name, pal[A_TXT]);
            hit_add(px + 18, yy, pw - 36, 26, 1600 + i);
        }
        text(back, px + 22, py + ph - 24, "Search app names or commands  |  Enter to run  |  Esc to close", pal[A_DIM]);
    }
    draw_launchpad(back);
    draw_control_center(back);
    draw_desktop_context(back);
    draw_system_bar(back, rh, rm);
    draw_island(back, ms);
    apply_brightness(back);
    flip();
}
static void frame(u32 ms) {
    static u32 last_phys, last_draw, last_blink = ~0u; static int started;
    cur_ms = ms;
    if (!started) { started = 1; last_phys = ms; }
    int steps = 0;
    while (ms - last_phys >= 16) { last_phys += 16; isl_step(); if (++steps > 4) { last_phys = ms; break; } }
    if (isl_expand && ms >= isl_until) { isl_expand = 0; idle_size(); dirty = 1; }
    if (spk_active && ms >= spk_until) { speaker_off(); spk_active = 0; }
    if (pwr_arm && ms >= pwr_until) { pwr_arm = 0; dirty = 1; }
    if (timer_on) {
        static u32 last_tsec;
        if (ms >= timer_end) { timer_on = 0; idle_size(); notify("Timer finished!", 1); if (alerts_enabled) { speaker_on(880); spk_active = 1; } spk_until = ms + 600; }
        else { u32 sec = (timer_end - ms + 999) / 1000; if (sec != last_tsec) { last_tsec = sec; dirty = 1; } }
    }
    if (game_on && !gover && ms - game_last >= (u32)game_ms()) { game_last = ms; game_step(); game_draw(); }
    u32 blink = ms / 500;
    { static u32 last_asec; if (nwin && ms / 1000 != last_asec) { last_asec = ms / 1000; dirty = 1; } if (nwin && app_fast) dirty = 1; }
    if (mouse_seen && my >= dky - 20 && my < dky + dkh) dirty = 1; /* animate dock hover while pointer is nearby */
    if ((dirty || isl_moving() || blink != last_blink) && ms - last_draw >= 14) {
        compose(ms); dirty = 0; last_blink = blink; last_draw = ms;
    }
}

/* ---- power: shutdown + restart (dock buttons and the terminal commands share these) ---- */
static void power_screen(const char *a, const char *b) {
    memset(back, 0, W * H * 4);
    text_s(back, ((int)W - 16 * slen(a)) / 2, (int)H / 2 - 40, a, 0xE6F4FF, 2);
    text(back, ((int)W - 8 * slen(b)) / 2, (int)H / 2 + 6, b, 0x7F9DB8);
    mouse_seen = 0; flip();
}
static void power_off(void) {
    power_screen("VinOS is shutting down", "It is now safe to turn off your computer.");
    outw(0x604, 0x2000); outw(0xB004, 0x2000); outw(0x4004, 0x3400);      /* QEMU / Bochs / VirtualBox ACPI power-off */
#ifndef HOSTTEST
    for (;;) __asm__ volatile("cli; hlt");                                  /* real hardware without ACPI support: stay on the message screen */
#endif
}
static void power_restart(void) {
    power_screen("Restarting VinOS", "");
    for (int t = 100000; (inb(0x64) & 2) && t; t--) {}
    outb(0x64, 0xFE);                                                        /* keyboard-controller reset line */
    outb(0xCF9, 0x02); outb(0xCF9, 0x06);                                    /* chipset reset register */
#ifndef HOSTTEST
    { struct { u16 lim; u32 base; } __attribute__((packed)) nul = {0, 0}; __asm__ volatile("lidt %0; int3" :: "m"(nul)); }   /* last resort: triple fault */
    for (;;) __asm__ volatile("cli; hlt");
#endif
}

static void kernel_init(void) {
    hardware_probe();
    terminal_visible = 0; launchpad_open = 0; launcher_open = 0; control_open = 0;
    nd[0].used = 1; nd[0].isdir = 1; nd[0].parent = -1; cwd = 0;
    home_node = fs_new(0, "Home", 1);
    desktop_node = fs_new(home_node, "Desktop", 1);
    documents_node = fs_new(home_node, "Documents", 1);
    downloads_node = fs_new(home_node, "Downloads", 1);
    pictures_node = fs_new(home_node, "Pictures", 1);
    music_node = fs_new(home_node, "Music", 1);
    videos_node = fs_new(home_node, "Videos", 1);
    projects_node = fs_new(home_node, "Projects", 1);
    { int welcome = fs_new(home_node, "Welcome.txt", 0); if (welcome > 0) {
        const char *msg = "Welcome to VinOS. Your files are stored in the temporary C: RAM disk in this build.\nPhysical laptop drives will appear here after a storage driver is added.\n";
        scpy(fdata[welcome], msg, FSIZE); nd[welcome].size = slen(fdata[welcome]);
    } }
    build_scene();
    t_clear();
    t_say(" VinOS 1.8  -  Glass Workspace desktop", A_ACC);
    t_say(" Type help, or commands to see all 250+. Press Tab to complete.", A_DIM);
    t_putc('\n', A_TXT);
    prompt();
    { static char dm[40]; int p = 0; const char *s = "VinOS  "; while (*s) dm[p++] = *s++; char nb[12];
      fmt_base(W, 10, nb); for (char *q = nb; *q; q++) dm[p++] = *q; dm[p++] = 'x'; fmt_base(H, 10, nb); for (char *q = nb; *q; q++) dm[p++] = *q; dm[p] = 0; notify(dm, 0); }
}

#ifndef HOSTTEST
static void vga_say(const char *s) {
    volatile u16 *v = (volatile u16 *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) v[i] = 0x0720;
    for (int i = 0; s[i]; i++) v[i] = 0x4F00 | (u8)s[i];
}
void kmain(u32 magic, u32 mbi) {
    u32 *m = (u32 *)mbi;
    if (magic != 0x2BADB002 || !(m[0] & (1 << 12)) || ((u8 *)m)[109] != 1 || ((u8 *)m)[108] != 32) {
        vga_say(" VinOS needs a 32-bit linear framebuffer. Boot it with GRUB (make iso). ");
        for (;;) __asm__ volatile("hlt");
    }
    fb = (u32 *)m[22]; PITCH = m[24]; W = m[25]; H = m[26];
    if (m[0] & 1) mem_kb = m[2] + 1024;
    if (W > MAXW) W = MAXW;
    if (H > MAXH) H = MAXH;
    mx = pmx = (int)W / 2; my = pmy = (int)H / 2;
    outb(0x43, 0x34); outb(0x40, 0); outb(0x40, 0);       /* PIT ch0: free-running 16-bit counter */
    mouse_init();
    kernel_init();
    for (;;) {
        int k = poll_key(); if (k) handle_key(k);
        frame(now_ms()); cursor_sync();
    }
}
#endif
