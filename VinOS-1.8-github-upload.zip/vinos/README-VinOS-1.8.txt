VinOS 1.8 - Dock shows only open apps
=====================================
- The dock always has two defaults: Terminal and This PC.
- Any other app appears in the dock only while it is open (running dot under it)
  and disappears when you close it. The dock grows/shrinks to fit.
- This PC button opens the This PC view in Files. A Files window shows its dot
  under This PC, not as an extra icon.
- All apps remain available from the VinOS logo (App Library) and Spotlight.
- Theme from 1.7 (macOS dark graphite glass) unchanged.
Build: make / make host-test / make iso. Not boot-tested on hardware.
